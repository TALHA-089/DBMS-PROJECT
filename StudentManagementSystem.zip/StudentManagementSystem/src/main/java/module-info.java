module com.example.studentmanagementsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires com.github.librepdf.openpdf;

    opens com.example.studentmanagementsystem to javafx.fxml;
    opens com.example.studentmanagementsystem.Models to javafx.base, javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Student to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Teacher to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageStudents to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageCourses to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageTeachers to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageDepartments to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageSections to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageFloors to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageRooms to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageTimeTable to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Admin.ManageSemesters to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Student.CourseRegistration to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Student.ViewTimeTable to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Student.ViewProfile to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Student.GPACalculator to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Student.Transcript to javafx.fxml;
    opens com.example.studentmanagementsystem.DashBoards.Student.NotesManager to javafx.fxml;

    exports com.example.studentmanagementsystem;
    exports com.example.studentmanagementsystem.DashBoards.Admin;
    exports com.example.studentmanagementsystem.DashBoards.Student;
    exports com.example.studentmanagementsystem.DashBoards.Teacher;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageStudents;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageCourses;
    exports com.example.studentmanagementsystem.Models to javafx.fxml;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageTeachers;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageDepartments;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageSections;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageFloors;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageRooms;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageTimeTable;
    exports com.example.studentmanagementsystem.DashBoards.Admin.ManageSemesters;
    exports com.example.studentmanagementsystem.DashBoards.Student.CourseRegistration;
    exports com.example.studentmanagementsystem.DashBoards.Student.ViewTimeTable;
    exports com.example.studentmanagementsystem.DashBoards.Student.ViewProfile;
    exports com.example.studentmanagementsystem.DashBoards.Student.GPACalculator;
    exports com.example.studentmanagementsystem.DashBoards.Student.Transcript;
    exports com.example.studentmanagementsystem.DashBoards.Student.NotesManager;
}
