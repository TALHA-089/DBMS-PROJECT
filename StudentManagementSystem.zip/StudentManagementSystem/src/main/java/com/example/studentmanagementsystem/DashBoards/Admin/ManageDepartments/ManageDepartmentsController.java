package com.example.studentmanagementsystem.DashBoards.Admin.ManageDepartments;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.DepartmentDisplayRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.sql.*;

public class ManageDepartmentsController {
    @FXML private TableView<DepartmentDisplayRow> tableDepartments;
    @FXML private TableColumn<DepartmentDisplayRow, Integer> colDepartmentID;
    @FXML private TableColumn<DepartmentDisplayRow, String> colDepartmentName;
    @FXML private TextField tfDepartmentName, tfSearch;
    @FXML private Button btnAdd, btnUpdate, btnDelete, btnClear, btnSearch;
    @FXML private ImageView GoBack;

    private int selectedDepartmentID = -1;

    @FXML
    public void initialize() {
        colDepartmentID.setCellValueFactory(new PropertyValueFactory<>("departmentID"));
        colDepartmentName.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        loadDepartments();

        tableDepartments.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                tfDepartmentName.setText(newSel.getDepartmentName());
                selectedDepartmentID = newSel.getDepartmentID();
            }
        });
    }

    private void loadDepartments() {
        ObservableList<DepartmentDisplayRow> rows = FXCollections.observableArrayList();
        String query = "SELECT * FROM Department";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                rows.add(new DepartmentDisplayRow(
                        rs.getInt("DepartmentID"),
                        rs.getString("DepartmentName")
                ));
            }
            tableDepartments.setItems(rows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Could not load departments: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearchDepartment(ActionEvent event) {
        String keyword = tfSearch.getText().trim();
        ObservableList<DepartmentDisplayRow> rows = FXCollections.observableArrayList();
        String query = "SELECT * FROM Department WHERE DepartmentName LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + keyword + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rows.add(new DepartmentDisplayRow(
                        rs.getInt("DepartmentID"),
                        rs.getString("DepartmentName")
                ));
            }
            tableDepartments.setItems(rows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Search Error", "Search failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddDepartment(ActionEvent event) {
        String name = tfDepartmentName.getText().trim();
        if (name.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Department name is required.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String insert = "INSERT INTO Department (DepartmentName) VALUES (?)";
            try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                stmt.setString(1, name);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Department added.");
                loadDepartments();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate")) {
                showAlert(Alert.AlertType.ERROR, "Duplicate Error", "Department name already exists.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Add Error", "Could not add department: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleUpdateDepartment(ActionEvent event) {
        if (selectedDepartmentID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No department selected.");
            return;
        }
        String name = tfDepartmentName.getText().trim();
        if (name.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Department name is required.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String update = "UPDATE Department SET DepartmentName=? WHERE DepartmentID=?";
            try (PreparedStatement stmt = conn.prepareStatement(update)) {
                stmt.setString(1, name);
                stmt.setInt(2, selectedDepartmentID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Department updated.");
                loadDepartments();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate")) {
                showAlert(Alert.AlertType.ERROR, "Duplicate Error", "Department name already exists.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Update Error", "Could not update department: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleDeleteDepartment(ActionEvent event) {
        if (selectedDepartmentID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No department selected.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String delete = "DELETE FROM Department WHERE DepartmentID=?";
            try (PreparedStatement stmt = conn.prepareStatement(delete)) {
                stmt.setInt(1, selectedDepartmentID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Department deleted.");
                loadDepartments();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            if (e.getMessage().contains("a foreign key constraint fails")) {
                showAlert(Alert.AlertType.ERROR, "Delete Error", "Cannot delete: Department is in use.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Delete Error", "Could not delete department: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleClearFields(ActionEvent event) {
        tfDepartmentName.clear();
        tfSearch.clear();
        tableDepartments.getSelectionModel().clearSelection();
        selectedDepartmentID = -1;
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow(); // or use any node from your scene
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
