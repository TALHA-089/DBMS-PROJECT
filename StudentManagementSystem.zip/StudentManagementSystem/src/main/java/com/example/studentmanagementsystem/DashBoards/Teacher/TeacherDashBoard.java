package com.example.studentmanagementsystem.DashBoards.Teacher;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DashBoards.Teacher.AssignedCourses.AssignedCoursesController;
import com.example.studentmanagementsystem.DashBoards.Teacher.MarkGrades.GradesController;
import com.example.studentmanagementsystem.DashBoards.Teacher.TimeTable.TimeTableController;
import com.example.studentmanagementsystem.DashBoards.Teacher.ViewProfile.ViewProfileController;
import com.example.studentmanagementsystem.Models.Teacher;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;

public class TeacherDashBoard {

    @FXML private Button btnAssignedCourses;
    @FXML private Button btnTimeTable;
    @FXML private Button btnGrades;
    @FXML private Button btnProfile;
    @FXML private Button btnSignOut;

    private Teacher currentTeacher;

    public void setTeacher(Teacher teacher) {
        this.currentTeacher = teacher;
    }

    @FXML
    private void goToAssignedCourses() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/ViewAssignedCourses/AssignedCourses.fxml"));
            Scene scene = new Scene(loader.load());
            AssignedCoursesController controller = loader.getController();
            controller.setTeacher(currentTeacher);
            Stage stage = (Stage) btnAssignedCourses.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Assigned Courses");
        } catch (Exception e) {
            showError("Could not open Assigned Courses", e);
        }
    }

    @FXML
    private void goToTimeTable() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/TeacherTimeTable/TeacherTimeTable.fxml"));
            Scene scene = new Scene(loader.load());
            TimeTableController controller = loader.getController();
            controller.setTeacher(currentTeacher);
            Stage stage = (Stage) btnTimeTable.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("My Timetable");
        } catch (Exception e) {
            showError("Could not open Timetable", e);
        }
    }

    @FXML
    private void goToGrades() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/MarkGrades/MarkGrades.fxml"));
            Scene scene = new Scene(loader.load());
            GradesController controller = loader.getController();
            controller.setTeacher(currentTeacher);
            Stage stage = (Stage) btnGrades.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Mark/Update Grades");
        } catch (Exception e) {
            showError("Could not open Grades", e);
        }
    }

    @FXML
    private void goToProfile() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/TeacherViewProfile/TeacherViewProfile.fxml"));
            Scene scene = new Scene(loader.load());
            ViewProfileController controller = loader.getController();
            controller.setTeacher(currentTeacher);
            Stage stage = (Stage) btnProfile.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Manage Profile");
        } catch (Exception e) {
            showError("Could not open Profile", e);
        }
    }

    @FXML public void signOut() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Sign Out");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to sign out?");
        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            try {
                Stage stage = (Stage) Stage.getWindows().filtered(Window::isShowing).getFirst();
                FXMLLoader fxmlLoader = new FXMLLoader(CMS.class.getResource("/FXMLS/CMS.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 470);
                stage.setScene(scene);
                stage.setTitle("Login Page");
                stage.setResizable(false);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Error", "Unable to return to login screen.");
            }
        }
    }

    private void showError(String msg, Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Navigation Error");
        alert.setHeaderText(msg);
        alert.setContentText(e.getMessage());
        alert.showAndWait();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
