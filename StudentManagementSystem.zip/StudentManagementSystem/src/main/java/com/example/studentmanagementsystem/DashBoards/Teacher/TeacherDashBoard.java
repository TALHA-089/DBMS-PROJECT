package com.example.studentmanagementsystem.DashBoards.Teacher;

import com.example.studentmanagementsystem.Models.Teacher;

public class TeacherDashBoard {

    private Teacher CurrentTeacher;

    public void setTeacherProfile(Teacher teacher) {
        CurrentTeacher.setTeacherID(teacher.getTeacherID());
        CurrentTeacher.setPassword(teacher.getPassword());
        CurrentTeacher.setName(teacher.getName());
        CurrentTeacher.setEmail(teacher.getEmail());
        CurrentTeacher.setPhone(teacher.getPhone());
    }

}
