package com.example.studentmanagementsystem.Models;

// This is ONLY for displaying in the TableView
public class StudentDisplayRow {
    private String enrollment;
    private String name;
    private String batch;
    private String department;
    private String section;

    public StudentDisplayRow(String enrollment, String name, String batch, String department, String section) {
        this.enrollment = enrollment;
        this.name = name;
        this.batch = batch;
        this.department = department;
        this.section = section;
    }

    public String getEnrollment() { return enrollment; }
    public String getName() { return name; }
    public String getBatch() { return batch; }
    public String getDepartment() { return department; }
    public String getSection() { return section; }
}
