package com.example.studentmanagementsystem.Models;

import javafx.beans.property.*;

public class CourseRow {
    private final IntegerProperty courseId;
    private final StringProperty courseCode, courseName, courseType, status;
    private final IntegerProperty creditHours;

    public CourseRow(int id, String code, String name, int credits, String type, String status) {
        this.courseId = new SimpleIntegerProperty(id);
        this.courseCode = new SimpleStringProperty(code);
        this.courseName = new SimpleStringProperty(name);
        this.creditHours = new SimpleIntegerProperty(credits);
        this.courseType = new SimpleStringProperty(type);
        this.status = new SimpleStringProperty(status);
    }
    public int getCourseId() { return courseId.get(); }
    public String getCourseCode() { return courseCode.get(); }
    public String getCourseName() { return courseName.get(); }
    public int getCreditHours() { return creditHours.get(); }
    public String getCourseType() { return courseType.get(); }
    public String getStatus() { return status.get(); }
    public IntegerProperty courseIdProperty() { return courseId; }
    public StringProperty courseCodeProperty() { return courseCode; }
    public StringProperty courseNameProperty() { return courseName; }
    public IntegerProperty creditHoursProperty() { return creditHours; }
    public StringProperty courseTypeProperty() { return courseType; }
    public StringProperty statusProperty() { return status; }
}
