package com.example.studentmanagementsystem.DashBoards.Admin.ManageSections;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.SectionDisplayRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.sql.*;

public class ManageSectionsController {

    @FXML private TableView<SectionDisplayRow> tableSections;
    @FXML private TableColumn<SectionDisplayRow, Integer> colSectionID;
    @FXML private TableColumn<SectionDisplayRow, String> colSectionName, colBatchName, colDepartmentName;
    @FXML private TextField tfSectionName, tfSearch;
    @FXML private ComboBox<String> cbDepartment, cbBatch;
    @FXML private Button btnAdd, btnUpdate, btnDelete, btnClear, btnSearch;
    @FXML private ImageView GoBack;

    private int selectedSectionID = -1;

    @FXML
    public void initialize() {
        colSectionID.setCellValueFactory(new PropertyValueFactory<>("sectionID"));
        colSectionName.setCellValueFactory(new PropertyValueFactory<>("sectionName"));
        colBatchName.setCellValueFactory(new PropertyValueFactory<>("batchName"));
        colDepartmentName.setCellValueFactory(new PropertyValueFactory<>("departmentName"));

        loadDepartments();
        loadSections();

        cbDepartment.setOnAction(e -> loadBatchesForDepartment());
        tableSections.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                tfSectionName.setText(newSel.getSectionName());
                cbDepartment.setValue(newSel.getDepartmentName());
                loadBatchesForDepartment();
                cbBatch.setValue(newSel.getBatchName());
                selectedSectionID = newSel.getSectionID();
            }
        });
    }

    private void loadDepartments() {
        ObservableList<String> departments = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DepartmentName FROM Department")) {
            while (rs.next()) departments.add(rs.getString("DepartmentName"));
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Unable to load departments:\n" + e.getMessage());
        }
        cbDepartment.setItems(departments);
    }

    private void loadBatchesForDepartment() {
        String departmentName = cbDepartment.getValue();
        ObservableList<String> batches = FXCollections.observableArrayList();
        if (departmentName == null) {
            cbBatch.setItems(batches);
            return;
        }
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT BatchName FROM Batch b JOIN Department d ON b.DepartmentID = d.DepartmentID WHERE d.DepartmentName = ?")) {
            stmt.setString(1, departmentName);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) batches.add(rs.getString("BatchName"));
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Unable to load batches:\n" + e.getMessage());
        }
        cbBatch.setItems(batches);
    }

    private void loadSections() {
        ObservableList<SectionDisplayRow> rows = FXCollections.observableArrayList();
        String query = "SELECT s.SectionID, s.SectionName, b.BatchName, d.DepartmentName " +
                "FROM Section s " +
                "JOIN Batch b ON s.BatchID = b.BatchID " +
                "JOIN Department d ON s.DepartmentID = d.DepartmentID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                rows.add(new SectionDisplayRow(
                        rs.getInt("SectionID"),
                        rs.getString("SectionName"),
                        rs.getString("BatchName"),
                        rs.getString("DepartmentName")
                ));
            }
            tableSections.setItems(rows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Could not load sections: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearchSection(ActionEvent event) {
        String keyword = tfSearch.getText().trim();
        ObservableList<SectionDisplayRow> rows = FXCollections.observableArrayList();
        String query = "SELECT s.SectionID, s.SectionName, b.BatchName, d.DepartmentName " +
                "FROM Section s " +
                "JOIN Batch b ON s.BatchID = b.BatchID " +
                "JOIN Department d ON s.DepartmentID = d.DepartmentID " +
                "WHERE s.SectionName LIKE ? OR b.BatchName LIKE ? OR d.DepartmentName LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            String like = "%" + keyword + "%";
            stmt.setString(1, like);
            stmt.setString(2, like);
            stmt.setString(3, like);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rows.add(new SectionDisplayRow(
                        rs.getInt("SectionID"),
                        rs.getString("SectionName"),
                        rs.getString("BatchName"),
                        rs.getString("DepartmentName")
                ));
            }
            tableSections.setItems(rows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Search Error", "Search failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddSection(ActionEvent event) {
        String sectionName = tfSectionName.getText().trim();
        String departmentName = cbDepartment.getValue();
        String batchName = cbBatch.getValue();

        if (sectionName.isEmpty() || departmentName == null || batchName == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all section fields.");
            return;
        }

        int departmentId = getDepartmentIdByName(departmentName);
        int batchId = getBatchIdByName(batchName, departmentId);

        if (departmentId == -1 || batchId == -1) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid department or batch.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String insert = "INSERT INTO Section (SectionName, BatchID, DepartmentID) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                stmt.setString(1, sectionName);
                stmt.setInt(2, batchId);
                stmt.setInt(3, departmentId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Section added.");
                loadSections();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Add Error", "Could not add section: " + e.getMessage());
        }
    }

    @FXML
    private void handleUpdateSection(ActionEvent event) {
        if (selectedSectionID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No section selected.");
            return;
        }
        String sectionName = tfSectionName.getText().trim();
        String departmentName = cbDepartment.getValue();
        String batchName = cbBatch.getValue();

        if (sectionName.isEmpty() || departmentName == null || batchName == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all section fields.");
            return;
        }

        int departmentId = getDepartmentIdByName(departmentName);
        int batchId = getBatchIdByName(batchName, departmentId);

        if (departmentId == -1 || batchId == -1) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid department or batch.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String update = "UPDATE Section SET SectionName=?, BatchID=?, DepartmentID=? WHERE SectionID=?";
            try (PreparedStatement stmt = conn.prepareStatement(update)) {
                stmt.setString(1, sectionName);
                stmt.setInt(2, batchId);
                stmt.setInt(3, departmentId);
                stmt.setInt(4, selectedSectionID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Section updated.");
                loadSections();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Update Error", "Could not update section: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteSection(ActionEvent event) {
        if (selectedSectionID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No section selected.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String delete = "DELETE FROM Section WHERE SectionID=?";
            try (PreparedStatement stmt = conn.prepareStatement(delete)) {
                stmt.setInt(1, selectedSectionID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Section deleted.");
                loadSections();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Delete Error", "Could not delete section: " + e.getMessage());
        }
    }

    @FXML
    private void handleClearFields(ActionEvent event) {
        tfSectionName.clear();
        tfSearch.clear();
        cbDepartment.getSelectionModel().clearSelection();
        cbBatch.getItems().clear();
        tableSections.getSelectionModel().clearSelection();
        selectedSectionID = -1;
    }

    private int getDepartmentIdByName(String departmentName) {
        String query = "SELECT DepartmentID FROM Department WHERE DepartmentName=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, departmentName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("DepartmentID");
        } catch (SQLException e) {
            // Already handled
        }
        return -1;
    }

    private int getBatchIdByName(String batchName, int departmentId) {
        String query = "SELECT BatchID FROM Batch WHERE BatchName=? AND DepartmentID=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, batchName);
            stmt.setInt(2, departmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("BatchID");
        } catch (SQLException e) {
            // Already handled
        }
        return -1;
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow(); // or use any node from your scene
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
