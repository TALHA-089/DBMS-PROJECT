package com.example.studentmanagementsystem.Models;

public class DepartmentDisplayRow {
    private int departmentID;
    private String departmentName;

    public DepartmentDisplayRow(int departmentID, String departmentName) {
        this.departmentID = departmentID;
        this.departmentName = departmentName;
    }

    public int getDepartmentID() { return departmentID; }
    public String getDepartmentName() { return departmentName; }
}
