package com.example.studentmanagementsystem.Models;

public class TeacherCourse {
    private String teacherId;
    private int courseId;

    public TeacherCourse(String teacherId, int courseId) {
        this.teacherId = teacherId;
        this.courseId = courseId;
    }

    public String getTeacherId() { return teacherId; }
    public void setTeacherId(String teacherId) { this.teacherId = teacherId; }

    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
}
