//package com.example.studentmanagementsystem.DashBoards.Admin.ManageStudents;
//
//import com.example.studentmanagementsystem.CMS;
//import com.example.studentmanagementsystem.DBconnection.DBConnection;
//import com.example.studentmanagementsystem.Models.Student;
//import com.example.studentmanagementsystem.Models.StudentDisplayRow;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Scene;
//import javafx.scene.control.*;
//import javafx.scene.control.cell.PropertyValueFactory;
//import javafx.stage.Stage;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//public class ManageStudentsController {
//
//    @FXML
//    private TextField tfStudentName, tfStudentID, tfEnrollment, tfSearch;
//    @FXML
//    private ComboBox<String> cbBatch, cbDepartment, cbSection;
//    @FXML
//    private TableView<StudentDisplayRow> tableStudents;
//    @FXML
//    private TableColumn<StudentDisplayRow, String> colName, colEnrollment, colBatch, colDepartment, colSection;
//    @FXML
//    private Button btnAdd, btnUpdate, btnDelete, btnClear;
//
//    public void initialize() {
//        loadBatches();
//        loadDepartments();
//        loadSections();
//        setupTable();
//        loadStudents();
//    }
//
//    private void showAlert(Alert.AlertType type, String title, String message) {
//        Alert alert = new Alert(type);
//        alert.setTitle(title);
//        alert.setHeaderText(null);
//        alert.setContentText(message);
//        alert.showAndWait();
//    }
//
//    private void loadBatches() {
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement("SELECT BatchName FROM Batch")) {
//            ResultSet rs = stmt.executeQuery();
//            List<String> batches = new ArrayList<>();
//            while (rs.next()) {
//                batches.add(rs.getString("BatchName"));
//            }
//            cbBatch.getItems().setAll(batches);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading batches.");
//        }
//    }
//
//    private void loadDepartments() {
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement("SELECT DepartmentName FROM Department")) {
//            ResultSet rs = stmt.executeQuery();
//            List<String> departments = new ArrayList<>();
//            while (rs.next()) {
//                departments.add(rs.getString("DepartmentName"));
//            }
//            cbDepartment.getItems().setAll(departments);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading departments.");
//        }
//    }
//
//    private void loadSections() {
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement("SELECT SectionName FROM Section")) {
//            ResultSet rs = stmt.executeQuery();
//            List<String> sections = new ArrayList<>();
//            while (rs.next()) {
//                sections.add(rs.getString("SectionName"));
//            }
//            cbSection.getItems().setAll(sections);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading sections.");
//        }
//    }
//
//    private void setupTable() {
//        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
//        colEnrollment.setCellValueFactory(new PropertyValueFactory<>("enrollment"));
//        colBatch.setCellValueFactory(new PropertyValueFactory<>("batch"));
//        colDepartment.setCellValueFactory(new PropertyValueFactory<>("department"));
//        colSection.setCellValueFactory(new PropertyValueFactory<>("section"));
//    }
//
//    private void loadStudents() {
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(
//                     "SELECT s.Enrollment, s.Name, b.BatchName, d.DepartmentName, sec.SectionName " +
//                             "FROM Student s " +
//                             "JOIN Batch b ON s.BatchID = b.BatchID " +
//                             "JOIN Section sec ON s.SectionID = sec.SectionID " +
//                             "JOIN Department d ON b.DepartmentID = d.DepartmentID"
//             )) {
//            ResultSet rs = stmt.executeQuery();
//            List<StudentDisplayRow> students = new ArrayList<>();
//            while (rs.next()) {
//                students.add(new StudentDisplayRow(
//                        rs.getString("Enrollment"),
//                        rs.getString("Name"),
//                        rs.getString("BatchName"),
//                        rs.getString("DepartmentName"),
//                        rs.getString("SectionName")
//                ));
//            }
//            tableStudents.getItems().setAll(students);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading students.");
//        }
//    }
//
//    private int getBatchID(String batchName) {
//        if (batchName == null) return -1;
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement("SELECT BatchID FROM Batch WHERE BatchName=?")) {
//            stmt.setString(1, batchName);
//            ResultSet rs = stmt.executeQuery();
//            if (rs.next()) return rs.getInt("BatchID");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return -1;
//    }
//
//    private int getSectionID(String sectionName) {
//        if (sectionName == null) return -1;
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement("SELECT SectionID FROM Section WHERE SectionName=?")) {
//            stmt.setString(1, sectionName);
//            ResultSet rs = stmt.executeQuery();
//            if (rs.next()) return rs.getInt("SectionID");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return -1;
//    }
//
//    // --- CRUD Operations ---
//
//    @FXML
//    private void handleAddStudent() {
//        String enrollment = tfEnrollment.getText();
//        String name = tfStudentName.getText();
//        String password = "default123";
//        String email = enrollment + "@example.com";
//        String phone = "0000000000";
//        int batchId = getBatchID(cbBatch.getValue());
//        int sectionId = getSectionID(cbSection.getValue());
//
//        if (enrollment.isEmpty() || name.isEmpty() || batchId == -1 || sectionId == -1) {
//            showAlert(Alert.AlertType.WARNING, "Missing Fields", "Please fill out all required fields.");
//            return;
//        }
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(
//                     "INSERT INTO Student (Enrollment, Name, Password, Email, Phone, BatchID, SectionID) VALUES (?, ?, ?, ?, ?, ?, ?)")
//        ) {
//            stmt.setString(1, enrollment);
//            stmt.setString(2, name);
//            stmt.setString(3, password);
//            stmt.setString(4, email);
//            stmt.setString(5, phone);
//            stmt.setInt(6, batchId);
//            stmt.setInt(7, sectionId);
//
//            stmt.executeUpdate();
//            loadStudents();
//            handleClearForm();
//            showAlert(Alert.AlertType.INFORMATION, "Student Added", "Student added successfully.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Add Failed", "Error adding student.");
//        }
//    }
//
//    @FXML
//    private void handleUpdateStudent() {
//        String enrollment = tfEnrollment.getText();
//        String name = tfStudentName.getText();
//        int batchId = getBatchID(cbBatch.getValue());
//        int sectionId = getSectionID(cbSection.getValue());
//
//        if (enrollment.isEmpty() || name.isEmpty() || batchId == -1 || sectionId == -1) {
//            showAlert(Alert.AlertType.WARNING, "Missing Fields", "Please fill out all fields.");
//            return;
//        }
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(
//                     "UPDATE Student SET Name=?, BatchID=?, SectionID=? WHERE Enrollment=?"
//             )) {
//            stmt.setString(1, name);
//            stmt.setInt(2, batchId);
//            stmt.setInt(3, sectionId);
//            stmt.setString(4, enrollment);
//
//            stmt.executeUpdate();
//            loadStudents();
//            handleClearForm();
//            showAlert(Alert.AlertType.INFORMATION, "Student Updated", "Student updated successfully.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Update Failed", "Error updating student.");
//        }
//    }
//
//    @FXML
//    private void handleDeleteStudent() {
//        String enrollment = tfEnrollment.getText();
//
//        if (enrollment.isEmpty()) {
//            showAlert(Alert.AlertType.WARNING, "No Student Selected", "Please select a student to delete.");
//            return;
//        }
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(
//                     "DELETE FROM Student WHERE Enrollment=?"
//             )) {
//            stmt.setString(1, enrollment);
//            stmt.executeUpdate();
//            loadStudents();
//            handleClearForm();
//            showAlert(Alert.AlertType.INFORMATION, "Student Deleted", "Student deleted successfully.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Delete Failed", "Error deleting student.");
//        }
//    }
//
//    @FXML
//    private void handleClearForm() {
//        tfStudentName.clear();
//        tfStudentID.clear();
//        tfEnrollment.clear();
//        tfSearch.clear();
//        cbBatch.getSelectionModel().clearSelection();
//        cbDepartment.getSelectionModel().clearSelection();
//        cbSection.getSelectionModel().clearSelection();
//        tableStudents.getSelectionModel().clearSelection();
//    }
//
//    @FXML
//    private void handleSearchStudent() {
//        String searchTerm = tfSearch.getText();
//        if (searchTerm.isEmpty()) {
//            loadStudents();
//            showAlert(Alert.AlertType.INFORMATION, "Search Cleared", "Showing all students.");
//            return;
//        }
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement(
//                     "SELECT s.Enrollment, s.Name, b.BatchName, d.DepartmentName, sec.SectionName " +
//                             "FROM Student s " +
//                             "JOIN Batch b ON s.BatchID = b.BatchID " +
//                             "JOIN Section sec ON s.SectionID = sec.SectionID " +
//                             "JOIN Department d ON b.DepartmentID = d.DepartmentID " +
//                             "WHERE s.Enrollment LIKE ? OR s.Name LIKE ?"
//             )) {
//            stmt.setString(1, "%" + searchTerm + "%");
//            stmt.setString(2, "%" + searchTerm + "%");
//            ResultSet rs = stmt.executeQuery();
//            List<StudentDisplayRow> students = new ArrayList<>();
//            while (rs.next()) {
//                students.add(new StudentDisplayRow(
//                        rs.getString("Enrollment"),
//                        rs.getString("Name"),
//                        rs.getString("BatchName"),
//                        rs.getString("DepartmentName"),
//                        rs.getString("SectionName")
//                ));
//            }
//            tableStudents.getItems().setAll(students);
//            showAlert(Alert.AlertType.INFORMATION, "Search Completed", students.size() + " student(s) found.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//            showAlert(Alert.AlertType.ERROR, "Search Error", "Failed to search students. Please try again.");
//        }
//    }
//
//    @FXML
//    public void GoBack() {
//        try {
//            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
//            Scene scene = new Scene(loader.load(), 600, 608);
//            Stage stage = (Stage) tfStudentName.getScene().getWindow(); // or use any node from your scene
//            stage.setScene(scene);
//            stage.setTitle("Admin Dashboard");
//            stage.setResizable(false);
//            stage.show();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//}
package com.example.studentmanagementsystem.DashBoards.Admin.ManageStudents;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.Models.StudentDisplayRow;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ManageStudentsController {

    @FXML private TextField tfStudentName, tfEnrollment, tfSearch;
    @FXML private ComboBox<String> cbBatch, cbDepartment, cbSection;
    @FXML private TableView<StudentDisplayRow> tableStudents;
    @FXML private TableColumn<StudentDisplayRow, String> colName, colEnrollment, colBatch, colDepartment, colSection;
    @FXML private Button btnAdd, btnUpdate, btnDelete, btnClear;

    @FXML
    public void initialize() {
        loadBatches();
        loadDepartments();
        loadSections();
        setupTable();
        loadStudents();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadBatches() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT BatchName FROM Batch")) {
            ResultSet rs = stmt.executeQuery();
            List<String> batches = new ArrayList<>();
            while (rs.next()) {
                batches.add(rs.getString("BatchName"));
            }
            cbBatch.getItems().setAll(batches);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading batches.");
        }
    }

    private void loadDepartments() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT DepartmentName FROM Department")) {
            ResultSet rs = stmt.executeQuery();
            List<String> departments = new ArrayList<>();
            while (rs.next()) {
                departments.add(rs.getString("DepartmentName"));
            }
            cbDepartment.getItems().setAll(departments);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading departments.");
        }
    }

    private void loadSections() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT SectionName FROM Section")) {
            ResultSet rs = stmt.executeQuery();
            List<String> sections = new ArrayList<>();
            while (rs.next()) {
                sections.add(rs.getString("SectionName"));
            }
            cbSection.getItems().setAll(sections);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading sections.");
        }
    }

    private void setupTable() {
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colEnrollment.setCellValueFactory(new PropertyValueFactory<>("enrollment"));
        colBatch.setCellValueFactory(new PropertyValueFactory<>("batch"));
        colDepartment.setCellValueFactory(new PropertyValueFactory<>("department"));
        colSection.setCellValueFactory(new PropertyValueFactory<>("section"));
    }

    private void loadStudents() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT s.Enrollment, s.Name, b.BatchName, d.DepartmentName, sec.SectionName " +
                             "FROM Student s " +
                             "JOIN Batch b ON s.BatchID = b.BatchID " +
                             "JOIN Section sec ON s.SectionID = sec.SectionID " +
                             "JOIN Department d ON b.DepartmentID = d.DepartmentID"
             )) {
            ResultSet rs = stmt.executeQuery();
            List<StudentDisplayRow> students = new ArrayList<>();
            while (rs.next()) {
                students.add(new StudentDisplayRow(
                        rs.getString("Enrollment"),
                        rs.getString("Name"),
                        rs.getString("BatchName"),
                        rs.getString("DepartmentName"),
                        rs.getString("SectionName")
                ));
            }
            tableStudents.getItems().setAll(students);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error loading students.");
        }
    }

    private int getBatchID(String batchName) {
        if (batchName == null) return -1;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT BatchID FROM Batch WHERE BatchName=?")) {
            stmt.setString(1, batchName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("BatchID");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getSectionID(String sectionName) {
        if (sectionName == null) return -1;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT SectionID FROM Section WHERE SectionName=?")) {
            stmt.setString(1, sectionName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("SectionID");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @FXML
    private void handleAddStudent() {
        String enrollment = tfEnrollment.getText();
        String name = tfStudentName.getText();
        String password = "default123";
        String email = enrollment + "@example.com";
        String phone = "0000000000";
        int batchId = getBatchID(cbBatch.getValue());
        int sectionId = getSectionID(cbSection.getValue());

        // Check Enrollment format
        if (!enrollment.matches("^01-131232-\\d{3}$")) {
            showAlert(Alert.AlertType.WARNING, "Enrollment Format", "Enrollment must be in format 01-131232-XXX");
            return;
        }

        if (enrollment.isEmpty() || name.isEmpty() || batchId == -1 || sectionId == -1) {
            showAlert(Alert.AlertType.WARNING, "Missing Fields", "Please fill out all required fields.");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO Student (Enrollment, Name, Password, Email, Phone, BatchID, SectionID) VALUES (?, ?, ?, ?, ?, ?, ?)")
        ) {
            stmt.setString(1, enrollment);
            stmt.setString(2, name);
            stmt.setString(3, password);
            stmt.setString(4, email);
            stmt.setString(5, phone);
            stmt.setInt(6, batchId);
            stmt.setInt(7, sectionId);

            stmt.executeUpdate();
            loadStudents();
            handleClearForm();
            showAlert(Alert.AlertType.INFORMATION, "Student Added", "Student added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Add Failed", "Error adding student.");
        }
    }

    @FXML
    private void handleUpdateStudent() {
        String enrollment = tfEnrollment.getText();
        String name = tfStudentName.getText();
        int batchId = getBatchID(cbBatch.getValue());
        int sectionId = getSectionID(cbSection.getValue());

        if (!enrollment.matches("^01-131232-\\d{3}$")) {
            showAlert(Alert.AlertType.WARNING, "Enrollment Format", "Enrollment must be in format 01-131232-XXX");
            return;
        }

        if (enrollment.isEmpty() || name.isEmpty() || batchId == -1 || sectionId == -1) {
            showAlert(Alert.AlertType.WARNING, "Missing Fields", "Please fill out all required fields.");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE Student SET Name=?, BatchID=?, SectionID=? WHERE Enrollment=?"
             )) {
            stmt.setString(1, name);
            stmt.setInt(2, batchId);
            stmt.setInt(3, sectionId);
            stmt.setString(4, enrollment);

            stmt.executeUpdate();
            loadStudents();
            handleClearForm();
            showAlert(Alert.AlertType.INFORMATION, "Student Updated", "Student updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Update Failed", "Error updating student.");
        }
    }

    @FXML
    private void handleDeleteStudent() {
        String enrollment = tfEnrollment.getText();

        if (enrollment.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "No Student Selected", "Please select a student to delete.");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "DELETE FROM Student WHERE Enrollment=?"
             )) {
            stmt.setString(1, enrollment);
            stmt.executeUpdate();
            loadStudents();
            handleClearForm();
            showAlert(Alert.AlertType.INFORMATION, "Student Deleted", "Student deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Delete Failed", "Error deleting student.");
        }
    }

    @FXML
    private void handleClearForm() {
        tfStudentName.clear();
        tfEnrollment.clear();
        tfSearch.clear();
        cbBatch.getSelectionModel().clearSelection();
        cbDepartment.getSelectionModel().clearSelection();
        cbSection.getSelectionModel().clearSelection();
        tableStudents.getSelectionModel().clearSelection();
    }

    @FXML
    private void handleSearchStudent() {
        String searchTerm = tfSearch.getText();
        if (searchTerm.isEmpty()) {
            loadStudents();
            showAlert(Alert.AlertType.INFORMATION, "Search Cleared", "Showing all students.");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT s.Enrollment, s.Name, b.BatchName, d.DepartmentName, sec.SectionName " +
                             "FROM Student s " +
                             "JOIN Batch b ON s.BatchID = b.BatchID " +
                             "JOIN Section sec ON s.SectionID = sec.SectionID " +
                             "JOIN Department d ON b.DepartmentID = d.DepartmentID " +
                             "WHERE s.Enrollment LIKE ? OR s.Name LIKE ?"
             )) {
            stmt.setString(1, "%" + searchTerm + "%");
            stmt.setString(2, "%" + searchTerm + "%");
            ResultSet rs = stmt.executeQuery();
            List<StudentDisplayRow> students = new ArrayList<>();
            while (rs.next()) {
                students.add(new StudentDisplayRow(
                        rs.getString("Enrollment"),
                        rs.getString("Name"),
                        rs.getString("BatchName"),
                        rs.getString("DepartmentName"),
                        rs.getString("SectionName")
                ));
            }
            tableStudents.getItems().setAll(students);
            showAlert(Alert.AlertType.INFORMATION, "Search Completed", students.size() + " student(s) found.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Search Error", "Failed to search students. Please try again.");
        }
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) tfStudentName.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
