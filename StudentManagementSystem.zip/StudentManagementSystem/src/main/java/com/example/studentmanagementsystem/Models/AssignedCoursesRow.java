package com.example.studentmanagementsystem.Models;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class AssignedCoursesRow {
    private final StringProperty courseCode, courseName, semesterName, sectionName;

    public AssignedCoursesRow(String code, String name, String sem, String sec) {
        this.courseCode = new SimpleStringProperty(code);
        this.courseName = new SimpleStringProperty(name);
        this.semesterName = new SimpleStringProperty(sem);
        this.sectionName = new SimpleStringProperty(sec);
    }
    public StringProperty courseCodeProperty() { return courseCode; }
    public StringProperty courseNameProperty() { return courseName; }
    public StringProperty semesterNameProperty() { return semesterName; }
    public StringProperty sectionNameProperty() { return sectionName; }

    public String getCourseCode() { return courseCode.get(); }
    public String getCourseName() { return courseName.get(); }
    public String getSemesterName() { return semesterName.get(); }
    public String getSectionName() { return sectionName.get(); }
}
