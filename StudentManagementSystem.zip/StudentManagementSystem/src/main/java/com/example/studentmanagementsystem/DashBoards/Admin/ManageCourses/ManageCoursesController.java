package com.example.studentmanagementsystem.DashBoards.Admin.ManageCourses;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.CourseViewRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import javafx.stage.Stage;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class ManageCoursesController {
    @FXML private TableView<CourseViewRow> tableCourses;
    @FXML private TableColumn<CourseViewRow, Integer> colCourseId;
    @FXML private TableColumn<CourseViewRow, String> colCourseCode, colCourseName, colDepartment, colSemester;
    @FXML private TextField tfSearch, tfCourseCode, tfCourseName;
    @FXML private ComboBox<String> cbDepartment, cbTeacher, cbSemester;
    @FXML private Button btnAdd, btnUpdate, btnDelete, btnClear, btnAssignTeacher, btnEnrollStudent, btnSearch;
    @FXML private ImageView GoBack;

    private ObservableList<String> departmentList = FXCollections.observableArrayList();
    private ObservableList<String> teacherList = FXCollections.observableArrayList();
    private ObservableList<String> semesterList = FXCollections.observableArrayList();
    // For mapping names to IDs
    private Map<String, Integer> departmentNameToId = new HashMap<>();
    private Map<String, Integer> semesterNameToId = new HashMap<>();
    private Map<Integer, String> semesterIdToName = new HashMap<>();

    private int selectedCourseId = -1;

    @FXML
    public void initialize() {
        colCourseId.setCellValueFactory(new PropertyValueFactory<>("courseId"));
        colCourseCode.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        colCourseName.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        colDepartment.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        colSemester.setCellValueFactory(new PropertyValueFactory<>("semesterName"));

        loadDepartments();
        loadSemesters();
        loadCourses();
        loadTeachers();

        tableCourses.setOnMouseClicked((MouseEvent event) -> {
            CourseViewRow selected = tableCourses.getSelectionModel().getSelectedItem();
            if (selected != null) {
                selectedCourseId = selected.getCourseId();
                tfCourseCode.setText(selected.getCourseCode());
                tfCourseName.setText(selected.getCourseName());
                cbDepartment.setValue(selected.getDepartmentName());
                cbSemester.setValue(selected.getSemesterName());
            }
        });
    }

    private void loadDepartments() {
        departmentList.clear();
        departmentNameToId.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT DepartmentID, DepartmentName FROM Department")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String name = rs.getString("DepartmentName");
                int id = rs.getInt("DepartmentID");
                departmentList.add(name);
                departmentNameToId.put(name, id);
            }
            cbDepartment.setItems(departmentList);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Unable to load departments: " + e.getMessage());
        }
    }

    private void loadSemesters() {
        semesterList.clear();
        semesterNameToId.clear();
        semesterIdToName.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT SemesterID, SemesterName FROM Semester")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("SemesterID");
                String name = rs.getString("SemesterName");
                semesterList.add(name);
                semesterNameToId.put(name, id);
                semesterIdToName.put(id, name);
            }
            cbSemester.setItems(semesterList);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Unable to load semesters: " + e.getMessage());
        }
    }

    private void loadCourses() {
        ObservableList<CourseViewRow> courseRows = FXCollections.observableArrayList();
        String query = "SELECT c.CourseID, c.CourseCode, c.CourseName, d.DepartmentName, c.SemesterID " +
                "FROM Course c JOIN Department d ON c.DepartmentID = d.DepartmentID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int semId = rs.getInt("SemesterID");
                String semName = semesterIdToName.getOrDefault(semId, "Not Set");
                courseRows.add(new CourseViewRow(
                        rs.getInt("CourseID"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getString("DepartmentName"),
                        semName
                ));
            }
            tableCourses.setItems(courseRows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Unable to load courses: " + e.getMessage());
        }
    }

    private void loadTeachers() {
        teacherList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT TeacherID, Name FROM Teacher")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String teacher = rs.getString("TeacherID") + " - " + rs.getString("Name");
                teacherList.add(teacher);
            }
            cbTeacher.setItems(teacherList);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Unable to load teachers: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearchCourse(ActionEvent event) {
        String keyword = tfSearch.getText().trim();
        ObservableList<CourseViewRow> courseRows = FXCollections.observableArrayList();
        String query = "SELECT c.CourseID, c.CourseCode, c.CourseName, d.DepartmentName, c.SemesterID " +
                "FROM Course c JOIN Department d ON c.DepartmentID = d.DepartmentID " +
                "WHERE c.CourseCode LIKE ? OR c.CourseName LIKE ? OR d.DepartmentName LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            String like = "%" + keyword + "%";
            stmt.setString(1, like);
            stmt.setString(2, like);
            stmt.setString(3, like);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int semId = rs.getInt("SemesterID");
                String semName = semesterIdToName.getOrDefault(semId, "Not Set");
                courseRows.add(new CourseViewRow(
                        rs.getInt("CourseID"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getString("DepartmentName"),
                        semName
                ));
            }
            tableCourses.setItems(courseRows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Search failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddCourse(ActionEvent event) {
        String code = tfCourseCode.getText().trim();
        String name = tfCourseName.getText().trim();
        String departmentName = cbDepartment.getValue();
        String semesterName = cbSemester.getValue();

        if (code.isEmpty() || name.isEmpty() || departmentName == null || semesterName == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all course fields including semester.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            int departmentId = departmentNameToId.getOrDefault(departmentName, -1);
            int semesterId = semesterNameToId.getOrDefault(semesterName, -1);
            if (departmentId == -1 || semesterId == -1) {
                showAlert(Alert.AlertType.ERROR, "Error", "Invalid department or semester.");
                return;
            }
            String insertQuery = "INSERT INTO Course (CourseCode, CourseName, DepartmentID, SemesterID) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
                stmt.setString(1, code);
                stmt.setString(2, name);
                stmt.setInt(3, departmentId);
                stmt.setInt(4, semesterId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Course added.");
                loadCourses();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Add failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleUpdateCourse(ActionEvent event) {
        if (selectedCourseId == -1) {
            showAlert(Alert.AlertType.ERROR, "Error", "No course selected.");
            return;
        }
        String code = tfCourseCode.getText().trim();
        String name = tfCourseName.getText().trim();
        String departmentName = cbDepartment.getValue();
        String semesterName = cbSemester.getValue();

        if (code.isEmpty() || name.isEmpty() || departmentName == null || semesterName == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all course fields including semester.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            int departmentId = departmentNameToId.getOrDefault(departmentName, -1);
            int semesterId = semesterNameToId.getOrDefault(semesterName, -1);
            if (departmentId == -1 || semesterId == -1) {
                showAlert(Alert.AlertType.ERROR, "Error", "Invalid department or semester.");
                return;
            }
            String updateQuery = "UPDATE Course SET CourseCode=?, CourseName=?, DepartmentID=?, SemesterID=? WHERE CourseID=?";
            try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
                stmt.setString(1, code);
                stmt.setString(2, name);
                stmt.setInt(3, departmentId);
                stmt.setInt(4, semesterId);
                stmt.setInt(5, selectedCourseId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Course updated.");
                loadCourses();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Update failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteCourse(ActionEvent event) {
        if (selectedCourseId == -1) {
            showAlert(Alert.AlertType.ERROR, "Error", "No course selected.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String deleteQuery = "DELETE FROM Course WHERE CourseID=?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {
                stmt.setInt(1, selectedCourseId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Course deleted.");
                loadCourses();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Delete failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleClearFields(ActionEvent event) {
        tfCourseCode.clear();
        tfCourseName.clear();
        cbDepartment.getSelectionModel().clearSelection();
        cbSemester.getSelectionModel().clearSelection();
        tableCourses.getSelectionModel().clearSelection();
        selectedCourseId = -1;
    }

    @FXML
    private void handleAssignTeacher(ActionEvent event) {
        if (selectedCourseId == -1) {
            showAlert(Alert.AlertType.ERROR, "Error", "No course selected.");
            return;
        }
        String teacherValue = cbTeacher.getValue();
        if (teacherValue == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Select a teacher.");
            return;
        }
        String teacherId = teacherValue.split(" - ")[0];
        try (Connection conn = DBConnection.getConnection()) {
            String check = "SELECT * FROM TeacherCourse WHERE TeacherID=? AND CourseID=?";
            try (PreparedStatement cstmt = conn.prepareStatement(check)) {
                cstmt.setString(1, teacherId);
                cstmt.setInt(2, selectedCourseId);
                ResultSet rs = cstmt.executeQuery();
                if (rs.next()) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Teacher already assigned to this course.");
                    return;
                }
            }
            String insert = "INSERT INTO TeacherCourse (TeacherID, CourseID) VALUES (?,?)";
            try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                stmt.setString(1, teacherId);
                stmt.setInt(2, selectedCourseId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher assigned to course.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Assignment failed: " + e.getMessage());
        }
    }

    public ObservableList<String> getAssignedTeachers(int courseId) {
        ObservableList<String> assigned = FXCollections.observableArrayList();
        String query = "SELECT t.TeacherID, t.Name FROM Teacher t " +
                "JOIN TeacherCourse tc ON t.TeacherID = tc.TeacherID " +
                "WHERE tc.CourseID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                assigned.add(rs.getString("TeacherID") + " - " + rs.getString("Name"));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Could not fetch assigned teachers: " + e.getMessage());
        }
        return assigned;
    }

    public ObservableList<String> getEnrolledStudents(int courseId) {
        ObservableList<String> enrolled = FXCollections.observableArrayList();
        String query = "SELECT s.Enrollment, s.Name FROM Student s " +
                "JOIN StudentCourse sc ON s.Enrollment = sc.Enrollment " +
                "WHERE sc.CourseID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                enrolled.add(rs.getString("Enrollment") + " - " + rs.getString("Name"));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Could not fetch enrolled students: " + e.getMessage());
        }
        return enrolled;
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
