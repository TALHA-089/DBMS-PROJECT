package com.example.studentmanagementsystem.Models;

public class TeacherDisplayRow {
    private String teacherID;
    private String name;
    private String departmentName;
    private String email;
    private String phone;

    public TeacherDisplayRow(String teacherID, String name, String departmentName, String email, String phone) {
        this.teacherID = teacherID;
        this.name = name;
        this.departmentName = departmentName;
        this.email = email;
        this.phone = phone;
    }

    public String getTeacherID() { return teacherID; }
    public String getName() { return name; }
    public String getDepartmentName() { return departmentName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
}
