package com.example.studentmanagementsystem.DashBoards.Admin.ManageTeachers;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.AssignedCourseRow;
import com.example.studentmanagementsystem.Models.TeacherDisplayRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.sql.*;

public class ManageTeachersController {

    @FXML private TableView<TeacherDisplayRow> tableTeachers;
    @FXML private TableColumn<TeacherDisplayRow, String> colTeacherID, colName, colDepartment, colEmail, colPhone;
    @FXML private TextField tfTeacherID, tfName, tfEmail, tfPhone, tfSearch;
    @FXML private PasswordField pfPassword;
    @FXML private ComboBox<String> cbDepartment, cbCourse;
    @FXML private TableView<AssignedCourseRow> tableAssignedCourses;
    @FXML private TableColumn<AssignedCourseRow, Integer> colCourseID;
    @FXML private TableColumn<AssignedCourseRow, String> colCourseCode, colCourseName;
    @FXML private ImageView GoBack;
    private String selectedTeacherID = null;

    @FXML
    public void initialize() {
        colTeacherID.setCellValueFactory(new PropertyValueFactory<>("teacherID"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colDepartment.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));

        colCourseID.setCellValueFactory(new PropertyValueFactory<>("courseId"));
        colCourseCode.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        colCourseName.setCellValueFactory(new PropertyValueFactory<>("courseName"));

        loadDepartments();
        loadCourses();
        loadTeachers();

        tableTeachers.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                setFieldsFromRow(newSelection);
                selectedTeacherID = newSelection.getTeacherID();
                loadAssignedCourses(selectedTeacherID);
            }
        });
    }

    private void setFieldsFromRow(TeacherDisplayRow row) {
        tfTeacherID.setText(row.getTeacherID());
        tfName.setText(row.getName());
        tfEmail.setText(row.getEmail());
        tfPhone.setText(row.getPhone());
        cbDepartment.setValue(row.getDepartmentName());
        pfPassword.clear();
    }

    private void loadDepartments() {
        ObservableList<String> departments = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DepartmentName FROM Department")) {
            while (rs.next()) departments.add(rs.getString("DepartmentName"));
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Unable to load departments:\n" + e.getMessage());
        }
        cbDepartment.setItems(departments);
    }

    private void loadCourses() {
        ObservableList<String> courses = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CourseID, CourseCode, CourseName FROM Course")) {
            while (rs.next()) {
                courses.add(rs.getInt("CourseID") + " - " + rs.getString("CourseCode") + " - " + rs.getString("CourseName"));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Unable to load courses:\n" + e.getMessage());
        }
        cbCourse.setItems(courses);
    }

    private void loadTeachers() {
        ObservableList<TeacherDisplayRow> teachers = FXCollections.observableArrayList();
        String query = "SELECT t.TeacherID, t.Name, t.Email, t.Phone, d.DepartmentName " +
                "FROM Teacher t JOIN Department d ON t.DepartmentID = d.DepartmentID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                teachers.add(new TeacherDisplayRow(
                        rs.getString("TeacherID"),
                        rs.getString("Name"),
                        rs.getString("DepartmentName"),
                        rs.getString("Email"),
                        rs.getString("Phone")
                ));
            }
            tableTeachers.setItems(teachers);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Unable to load teachers:\n" + e.getMessage());
        }
    }

    private void loadAssignedCourses(String teacherID) {
        ObservableList<AssignedCourseRow> assigned = FXCollections.observableArrayList();
        String query = "SELECT c.CourseID, c.CourseCode, c.CourseName " +
                "FROM Course c JOIN TeacherCourse tc ON c.CourseID = tc.CourseID " +
                "WHERE tc.TeacherID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, teacherID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                assigned.add(new AssignedCourseRow(
                        rs.getInt("CourseID"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName")
                ));
            }
            tableAssignedCourses.setItems(assigned);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Could not fetch assigned courses:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleSearchTeacher(ActionEvent event) {
        String keyword = tfSearch.getText().trim();
        ObservableList<TeacherDisplayRow> teachers = FXCollections.observableArrayList();
        String query = "SELECT t.TeacherID, t.Name, t.Email, t.Phone, d.DepartmentName " +
                "FROM Teacher t JOIN Department d ON t.DepartmentID = d.DepartmentID " +
                "WHERE t.TeacherID LIKE ? OR t.Name LIKE ? OR t.Email LIKE ? OR d.DepartmentName LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            String like = "%" + keyword + "%";
            stmt.setString(1, like);
            stmt.setString(2, like);
            stmt.setString(3, like);
            stmt.setString(4, like);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                teachers.add(new TeacherDisplayRow(
                        rs.getString("TeacherID"),
                        rs.getString("Name"),
                        rs.getString("DepartmentName"),
                        rs.getString("Email"),
                        rs.getString("Phone")
                ));
            }
            tableTeachers.setItems(teachers);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Search Error", "Search failed:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleAddTeacher(ActionEvent event) {
        String teacherID = tfTeacherID.getText().trim();
        String name = tfName.getText().trim();
        String departmentName = cbDepartment.getValue();
        String email = tfEmail.getText().trim();
        String phone = tfPhone.getText().trim();
        String password = pfPassword.getText();

        if (teacherID.isEmpty() || name.isEmpty() || departmentName == null || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Please fill all fields.");
            return;
        }

        int departmentId = getDepartmentIdByName(departmentName);
        if (departmentId == -1) {
            showAlert(Alert.AlertType.ERROR, "Department Error", "Invalid department.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String insert = "INSERT INTO Teacher (TeacherID, Password, Name, Email, Phone, DepartmentID) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                stmt.setString(1, teacherID);
                stmt.setString(2, password);
                stmt.setString(3, name);
                stmt.setString(4, email);
                stmt.setString(5, phone);
                stmt.setInt(6, departmentId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher added.");
                loadTeachers();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Add Error", "Could not add teacher:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleUpdateTeacher(ActionEvent event) {
        if (selectedTeacherID == null) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No teacher selected.");
            return;
        }
        String name = tfName.getText().trim();
        String departmentName = cbDepartment.getValue();
        String email = tfEmail.getText().trim();
        String phone = tfPhone.getText().trim();
        String password = pfPassword.getText();

        if (name.isEmpty() || departmentName == null || email.isEmpty() || phone.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Please fill all fields.");
            return;
        }

        int departmentId = getDepartmentIdByName(departmentName);
        if (departmentId == -1) {
            showAlert(Alert.AlertType.ERROR, "Department Error", "Invalid department.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String update = "UPDATE Teacher SET Name=?, Email=?, Phone=?, DepartmentID=?" +
                    (password.isEmpty() ? "" : ", Password=?") +
                    " WHERE TeacherID=?";
            try (PreparedStatement stmt = conn.prepareStatement(update)) {
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, phone);
                stmt.setInt(4, departmentId);
                int paramIndex = 5;
                if (!password.isEmpty()) {
                    stmt.setString(paramIndex++, password);
                }
                stmt.setString(paramIndex, selectedTeacherID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher updated.");
                loadTeachers();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Update Error", "Could not update teacher:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteTeacher(ActionEvent event) {
        if (selectedTeacherID == null) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No teacher selected.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String delete = "DELETE FROM Teacher WHERE TeacherID=?";
            try (PreparedStatement stmt = conn.prepareStatement(delete)) {
                stmt.setString(1, selectedTeacherID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher deleted.");
                loadTeachers();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Delete Error", "Could not delete teacher:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleClearFields(ActionEvent event) {
        tfTeacherID.clear();
        tfName.clear();
        tfEmail.clear();
        tfPhone.clear();
        pfPassword.clear();
        cbDepartment.getSelectionModel().clearSelection();
        cbCourse.getSelectionModel().clearSelection();
        tableTeachers.getSelectionModel().clearSelection();
        tableAssignedCourses.setItems(FXCollections.emptyObservableList());
        selectedTeacherID = null;
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) {
        if (selectedTeacherID == null) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No teacher selected.");
            return;
        }
        String courseString = cbCourse.getValue();
        if (courseString == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Select a course.");
            return;
        }
        int courseId = Integer.parseInt(courseString.split(" - ")[0]);
        try (Connection conn = DBConnection.getConnection()) {
            String check = "SELECT * FROM TeacherCourse WHERE TeacherID=? AND CourseID=?";
            try (PreparedStatement checkStmt = conn.prepareStatement(check)) {
                checkStmt.setString(1, selectedTeacherID);
                checkStmt.setInt(2, courseId);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    showAlert(Alert.AlertType.ERROR, "Assignment Error", "Teacher already assigned to this course.");
                    return;
                }
            }
            String insert = "INSERT INTO TeacherCourse (TeacherID, CourseID) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                stmt.setString(1, selectedTeacherID);
                stmt.setInt(2, courseId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Course assigned to teacher.");
                loadAssignedCourses(selectedTeacherID);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Assign Error", "Could not assign course:\n" + e.getMessage());
        }
    }

    private int getDepartmentIdByName(String departmentName) {
        String query = "SELECT DepartmentID FROM Department WHERE DepartmentName=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, departmentName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("DepartmentID");
        } catch (SQLException e) {
            // already handled
        }
        return -1;
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow(); // or use any node from your scene
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
