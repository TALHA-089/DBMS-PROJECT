package com.example.studentmanagementsystem.DashBoards.Admin.ManageSemesters;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.Models.SemesterRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.sql.*;

public class ManageSemestersController {

    @FXML private TableView<SemesterRow> tableSemesters;
    @FXML private TableColumn<SemesterRow, Integer> colSemesterId;
    @FXML private TableColumn<SemesterRow, String> colSemesterName, colSemesterYear, colStatus;
    @FXML private TextField tfSemesterName, tfYear;
    @FXML private ComboBox<String> cbStatus;
    @FXML private Button btnAdd, btnUpdate, btnDelete, btnClear;
    @FXML private ImageView GoBack;

    private int selectedSemesterId = -1;

    @FXML
    public void initialize() {
        colSemesterId.setCellValueFactory(cell -> cell.getValue().semesterIdProperty().asObject());
        colSemesterName.setCellValueFactory(cell -> cell.getValue().semesterNameProperty());
        colSemesterYear.setCellValueFactory(cell -> cell.getValue().yearProperty());
        colStatus.setCellValueFactory(cell -> cell.getValue().statusProperty());

        cbStatus.setItems(FXCollections.observableArrayList("Active", "Inactive"));

        loadSemesters();

        tableSemesters.setOnMouseClicked(this::onTableClick);
    }

    private void loadSemesters() {
        ObservableList<SemesterRow> list = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Semester")) {
            while (rs.next()) {
                list.add(new SemesterRow(
                        rs.getInt("SemesterID"),
                        rs.getString("SemesterName"),
                        rs.getString("Year"),
                        rs.getString("Status")
                ));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "DB Error", "Could not load semesters:\n" + e.getMessage());
        }
        tableSemesters.setItems(list);
    }

    @FXML
    private void handleAddSemester() {
        String name = tfSemesterName.getText().trim();
        String year = tfYear.getText().trim();
        String status = cbStatus.getValue();

        if (name.isEmpty() || year.isEmpty() || status == null) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "All fields are required.");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO Semester (SemesterName, Year, Status) VALUES (?, ?, ?)")) {
            stmt.setString(1, name);
            stmt.setString(2, year);
            stmt.setString(3, status);
            stmt.executeUpdate();
            showAlert(Alert.AlertType.INFORMATION, "Success", "Semester added!");
            loadSemesters();
            clearFields();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Add Failed", e.getMessage());
        }
    }

    @FXML
    private void handleUpdateSemester() {
        if (selectedSemesterId == -1) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Select a semester from the table.");
            return;
        }
        String name = tfSemesterName.getText().trim();
        String year = tfYear.getText().trim();
        String status = cbStatus.getValue();

        if (name.isEmpty() || year.isEmpty() || status == null) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "All fields are required.");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE Semester SET SemesterName=?, Year=?, Status=? WHERE SemesterID=?")) {
            stmt.setString(1, name);
            stmt.setString(2, year);
            stmt.setString(3, status);
            stmt.setInt(4, selectedSemesterId);
            stmt.executeUpdate();
            showAlert(Alert.AlertType.INFORMATION, "Success", "Semester updated!");
            loadSemesters();
            clearFields();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Update Failed", e.getMessage());
        }
    }

    @FXML
    private void handleDeleteSemester() {
        if (selectedSemesterId == -1) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Select a semester from the table.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure to delete this semester?", ButtonType.YES, ButtonType.NO);
        if (confirm.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "DELETE FROM Semester WHERE SemesterID=?")) {
            stmt.setInt(1, selectedSemesterId);
            stmt.executeUpdate();
            showAlert(Alert.AlertType.INFORMATION, "Deleted", "Semester deleted!");
            loadSemesters();
            clearFields();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Delete Failed", e.getMessage());
        }
    }

    @FXML
    private void handleClearFields() {
        clearFields();
    }

    private void clearFields() {
        tfSemesterName.clear();
        tfYear.clear();
        cbStatus.getSelectionModel().clearSelection();
        selectedSemesterId = -1;
        tableSemesters.getSelectionModel().clearSelection();
    }

    private void onTableClick(MouseEvent event) {
        SemesterRow row = tableSemesters.getSelectionModel().getSelectedItem();
        if (row != null) {
            selectedSemesterId = row.getSemesterId();
            tfSemesterName.setText(row.getSemesterName());
            tfYear.setText(row.getYear());
            cbStatus.setValue(row.getStatus());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow(); // or use any node from your scene
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
