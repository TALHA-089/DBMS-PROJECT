package com.example.studentmanagementsystem;

import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.DashBoards.Student.StudentDashBoard;
import com.example.studentmanagementsystem.DashBoards.Teacher.TeacherDashBoard;
import com.example.studentmanagementsystem.Models.Admin;
import com.example.studentmanagementsystem.Models.Student;
import com.example.studentmanagementsystem.Models.Teacher;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class CMSController implements Initializable {

    @FXML
    private Label LabelName;

    @FXML
    private Button btnLogin;

    @FXML
    private Button btnExit;

    @FXML
    private TextField tfUserName;

    @FXML
    private PasswordField pfPassword;

    @FXML
    private ComboBox<String> cbUserType;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cbUserType.getItems().addAll("Admin", "Student", "Teacher");

        cbUserType.valueProperty().addListener((observable, oldValue, newValue) -> {
            if ("Admin".equalsIgnoreCase(newValue)) {
                LabelName.setText("USERNAME");
            } else if ("Student".equalsIgnoreCase(newValue)) {
                LabelName.setText("ENROLLMENT");
            } else if ("Teacher".equalsIgnoreCase(newValue)) {
                LabelName.setText("TEACHER ID");
            }
        });
    }


    @FXML
    protected void LoginUser() {
        String id = tfUserName.getText();
        String password = pfPassword.getText();

        if (id.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "EMPTY FIELDS!", "PLEASE FILL OUT ALL THE FIELDS");
            return;
        }

        String userType = cbUserType.getValue();
        if (userType == null) {
            showAlert(Alert.AlertType.ERROR, "NO USER TYPE SELECTED", "PLEASE SELECT A USER TYPE");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String query;
            switch (userType) {
                case "Admin" -> query = "SELECT * FROM Admin WHERE UserName=? AND Password=?";
                case "Student" -> query = "SELECT * FROM Student WHERE Enrollment=? AND Password=?";
                case "Teacher" -> query = "SELECT * FROM Teacher WHERE TeacherID=? AND Password=?";
                default -> {
                    showAlert(Alert.AlertType.ERROR, "INVALID USER TYPE", "UNSUPPORTED USER TYPE");
                    return;
                }
            }

            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, id);
                stmt.setString(2, password);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        Stage stage = (Stage) btnLogin.getScene().getWindow();

                        switch (userType) {
                            case "Admin" -> {
                                String userName = rs.getString("UserName");
                                Admin admin = new Admin(userName, password);
                                showAlert(Alert.AlertType.INFORMATION, "LOGIN SUCCESS", "WELCOME " + userName);

                                FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
                                Scene scene = new Scene(loader.load(), 609, 465);
                                stage.setScene(scene);
                                stage.setTitle("Admin Dashboard");
                                stage.setResizable(false);
                                stage.show();
                            }

                            case "Student" -> {
                                Student student = new Student(
                                        rs.getString("Enrollment"),
                                        rs.getString("Name"),
                                        password,
                                        rs.getString("Email"),
                                        rs.getString("Phone"),
                                        rs.getInt("BatchID"),
                                        rs.getInt("SectionID")
                                );
                                showAlert(Alert.AlertType.INFORMATION, "LOGIN SUCCESS", "WELCOME " + student.getName());

                                FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
                                stage.setScene(new Scene(loader.load(), 600, 400));
                                StudentDashBoard controller = loader.getController();
                                controller.setStudentProfile(student);
                            }

                            case "Teacher" -> {
                                Teacher teacher = new Teacher(
                                        rs.getString("TeacherID"),
                                        password,
                                        rs.getString("Name"),
                                        rs.getString("Email"),
                                        rs.getString("Phone"),
                                        rs.getInt("DepartmentID")
                                );
                                showAlert(Alert.AlertType.INFORMATION, "LOGIN SUCCESS", "WELCOME " + teacher.getName());

                                FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
                                stage.setScene(new Scene(loader.load(), 600, 420));
                                TeacherDashBoard controller = loader.getController();
                                controller.setTeacher(teacher);
                            }
                        }

                    } else {
                        showAlert(Alert.AlertType.ERROR, "LOGIN FAILED", "USER NOT FOUND!");
                    }
                }
            }

        } catch (SQLException | IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "DATABASE ERROR", "UNABLE TO CONNECT OR QUERY DATABASE");
        }
    }



    @FXML
    protected void ExitApplication() {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Exit Confirmation");
        confirmationAlert.setHeaderText(null);
        confirmationAlert.setContentText("Are you sure you want to exit the application?");

        ButtonType result = confirmationAlert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            Stage stage = (Stage) btnExit.getScene().getWindow();
            stage.close();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


}