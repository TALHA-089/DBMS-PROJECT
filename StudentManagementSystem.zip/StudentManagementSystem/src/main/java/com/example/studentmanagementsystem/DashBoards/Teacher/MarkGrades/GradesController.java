package com.example.studentmanagementsystem.DashBoards.Teacher.MarkGrades;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.DashBoards.Teacher.TeacherDashBoard;
import com.example.studentmanagementsystem.Models.Teacher;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

import java.sql.*;

public class GradesController {

    @FXML private ComboBox<String> cbCourse;
    @FXML private ComboBox<String> cbSection;
    @FXML private Button btnLoadStudents, btnSaveGrades, btnGoBack;
    @FXML private TableView<StudentRow> tableGrades;
    @FXML private TableColumn<StudentRow, String> colEnrollment, colStudentName, colGrade, colStatus;

    private Teacher cTeacher; // Set after login

    // Data Model for TableView
    public static class StudentRow {
        private final StringProperty enrollment = new SimpleStringProperty();
        private final StringProperty studentName = new SimpleStringProperty();
        private final StringProperty grade = new SimpleStringProperty();
        private final StringProperty status = new SimpleStringProperty();

        public StudentRow(String enrollment, String studentName, String grade, String status) {
            setEnrollment(enrollment);
            setStudentName(studentName);
            setGrade(grade);
            setStatus(status);
        }
        public String getEnrollment() { return enrollment.get(); }
        public void setEnrollment(String v) { enrollment.set(v); }
        public StringProperty enrollmentProperty() { return enrollment; }

        public String getStudentName() { return studentName.get(); }
        public void setStudentName(String v) { studentName.set(v); }
        public StringProperty studentNameProperty() { return studentName; }

        public String getGrade() { return grade.get(); }
        public void setGrade(String v) { grade.set(v); }
        public StringProperty gradeProperty() { return grade; }

        public String getStatus() { return status.get(); }
        public void setStatus(String v) { status.set(v); }
        public StringProperty statusProperty() { return status; }
    }

    @FXML
    public void initialize() {
        colEnrollment.setCellValueFactory(data -> data.getValue().enrollmentProperty());
        colStudentName.setCellValueFactory(data -> data.getValue().studentNameProperty());
        // Use ComboBoxTableCell for grades
        ObservableList<String> gradeOptions = FXCollections.observableArrayList(
                "", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"
        );
        colGrade.setCellValueFactory(data -> data.getValue().gradeProperty());
        colGrade.setCellFactory(ComboBoxTableCell.forTableColumn(gradeOptions));
        colGrade.setOnEditCommit(evt -> evt.getRowValue().setGrade(evt.getNewValue()));

        colStatus.setCellValueFactory(data -> data.getValue().statusProperty());
        colStatus.setCellFactory(TextFieldTableCell.forTableColumn());
        colStatus.setOnEditCommit(evt -> evt.getRowValue().setStatus(evt.getNewValue()));

        tableGrades.setEditable(true);
        cbCourse.setOnAction(e -> loadSections());
        btnLoadStudents.setOnAction(e -> loadStudents());
        btnSaveGrades.setOnAction(e -> saveGrades());
        btnGoBack.setOnAction(e -> goBack());
    }

    public void setTeacher(Teacher t) {
        this.cTeacher = t;
        loadCourses();
    }

    private void loadCourses() {
        cbCourse.getItems().clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT c.CourseCode, c.CourseName FROM TeacherCourse tc " +
                             "JOIN Course c ON tc.CourseID = c.CourseID " +
                             "WHERE tc.TeacherID = ?"
             )) {
            stmt.setString(1, cTeacher.getTeacherID());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String item = rs.getString("CourseCode") + " - " + rs.getString("CourseName");
                cbCourse.getItems().add(item);
            }
        } catch (Exception e) {
            showAlert("Load courses error: " + e.getMessage());
        }
        cbSection.getItems().clear();
        tableGrades.getItems().clear();
    }

    private void loadSections() {
        cbSection.getItems().clear();
        tableGrades.getItems().clear();
        String selectedCourse = cbCourse.getValue();
        if (selectedCourse == null) return;
        String courseCode = selectedCourse.split(" - ")[0];
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT s.SectionName FROM Course c " +
                             "JOIN CourseSection cs ON c.CourseID = cs.CourseID " +
                             "JOIN Section s ON cs.SectionID = s.SectionID " +
                             "WHERE c.CourseCode = ?"
             )) {
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                cbSection.getItems().add(rs.getString("SectionName"));
            }
        } catch (Exception e) {
            showAlert("Load sections error: " + e.getMessage());
        }
    }

    private void loadStudents() {
        tableGrades.getItems().clear();
        String selectedCourse = cbCourse.getValue();
        String selectedSection = cbSection.getValue();
        if (selectedCourse == null || selectedSection == null) {
            showAlert("Select both course and section!");
            return;
        }
        String courseCode = selectedCourse.split(" - ")[0];

        // Get CourseID, SectionID, SemesterID
        int courseId = -1, sectionId = -1, semesterId = -1;
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT CourseID FROM Course WHERE CourseCode=?");
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) courseId = rs.getInt("CourseID");
            stmt.close();

            stmt = conn.prepareStatement("SELECT SectionID FROM Section WHERE SectionName=?");
            stmt.setString(1, selectedSection);
            rs = stmt.executeQuery();
            if (rs.next()) sectionId = rs.getInt("SectionID");
            stmt.close();

            stmt = conn.prepareStatement("SELECT SemesterID FROM Semester WHERE Status='Active' LIMIT 1");
            rs = stmt.executeQuery();
            if (rs.next()) semesterId = rs.getInt("SemesterID");
            stmt.close();
        } catch (Exception e) { showAlert("DB error: " + e.getMessage()); }

        if (courseId == -1 || sectionId == -1 || semesterId == -1) {
            showAlert("Course/section/semester not found.");
            return;
        }

        // Now get all students enrolled in this section for this course and semester
        ObservableList<StudentRow> students = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT s.Enrollment, s.Name, sg.Grade, sg.Status " +
                             "FROM Student s " +
                             "JOIN StudentGrade sg ON sg.Enrollment = s.Enrollment " +
                             "WHERE sg.CourseID = ? AND sg.SemesterID = ?"
             )) {
            stmt.setInt(1, courseId);
            stmt.setInt(2, semesterId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                students.add(new StudentRow(
                        rs.getString("Enrollment"),
                        rs.getString("Name"),
                        rs.getString("Grade") == null ? "" : rs.getString("Grade"),
                        rs.getString("Status") == null ? "In Progress" : rs.getString("Status")
                ));
            }
        } catch (Exception e) {
            showAlert("Load students error: " + e.getMessage());
        }
        tableGrades.setItems(students);
    }

    private void saveGrades() {
        String selectedCourse = cbCourse.getValue();
        String selectedSection = cbSection.getValue();
        if (selectedCourse == null || selectedSection == null) {
            showAlert("Select both course and section!");
            return;
        }
        String courseCode = selectedCourse.split(" - ")[0];
        int courseId = -1, semesterId = -1;
        try (Connection conn = DBConnection.getConnection()) {
            // Get CourseID
            try (PreparedStatement stmt = conn.prepareStatement("SELECT CourseID FROM Course WHERE CourseCode=?")) {
                stmt.setString(1, courseCode);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) courseId = rs.getInt("CourseID");
                }
            }
            // Get Active SemesterID
            try (PreparedStatement stmt = conn.prepareStatement("SELECT SemesterID FROM Semester WHERE Status='Active' LIMIT 1")) {
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) semesterId = rs.getInt("SemesterID");
                }
            }
        } catch (Exception e) {
            showAlert("DB error: " + e.getMessage());
            return;
        }

        if (courseId == -1 || semesterId == -1) {
            showAlert("Course/semester not found.");
            return;
        }

        ObservableList<StudentRow> students = tableGrades.getItems();

        try (Connection conn = DBConnection.getConnection()) {
            String updateSql = "UPDATE StudentGrade SET Grade = ?, Status = 'Completed' WHERE Enrollment = ? AND CourseID = ? AND SemesterID = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                for (StudentRow s : students) {
                    stmt.setString(1, s.getGrade());      // e.g. "A", "B+", ...
                    stmt.setString(2, s.getEnrollment()); // Enrollment number
                    stmt.setInt(3, courseId);
                    stmt.setInt(4, semesterId);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
            showAlert("Grades updated successfully!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            showAlert("Failed to update grades: " + e.getMessage());
        }
    }


    private void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 600, 420));
            TeacherDashBoard controller = loader.getController();
            controller.setTeacher(cTeacher);
        } catch (Exception e) {
            showAlert("Navigation failed: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        showAlert(msg, Alert.AlertType.ERROR);
    }
    private void showAlert(String msg, Alert.AlertType type) {
        Alert alert = new Alert(type, msg, ButtonType.OK);
        alert.showAndWait();
    }
}
