package com.example.studentmanagementsystem.DashBoards.Teacher.AssignedCourses;

import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.DashBoards.Teacher.TeacherDashBoard;
import com.example.studentmanagementsystem.Models.Teacher;
import com.example.studentmanagementsystem.Models.AssignedCoursesRow;
import com.example.studentmanagementsystem.CMS;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AssignedCoursesController {

    @FXML private TableView<AssignedCoursesRow> tableAssignedCourses;
    @FXML private TableColumn<AssignedCoursesRow, String> colCourseCode, colCourseName, colSemester, colSection;
    @FXML private Button btnGoBack;

    private Teacher cTeacher; // Set after login

    public void setTeacher(Teacher t) {
        this.cTeacher = t;
        loadAssignedCourses();
    }

    @FXML
    public void initialize() {
        colCourseCode.setCellValueFactory(data -> data.getValue().courseCodeProperty());
        colCourseName.setCellValueFactory(data -> data.getValue().courseNameProperty());
        colSemester.setCellValueFactory(data -> data.getValue().semesterNameProperty());
        colSection.setCellValueFactory(data -> data.getValue().sectionNameProperty());
        // Data loaded in setTeacher()
    }

    private void loadAssignedCourses() {
        ObservableList<AssignedCoursesRow> list = FXCollections.observableArrayList();
        if (cTeacher == null) {
            showAlert("Teacher not set.");
            return;
        }
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT c.CourseCode, c.CourseName, s.SemesterName, sec.SectionName " +
                             "FROM TeacherCourse tc " +
                             "JOIN Course c ON tc.CourseID = c.CourseID " +
                             "JOIN Semester s ON c.SemesterID = s.SemesterID " +
                             "JOIN CourseSection cs ON c.CourseID = cs.CourseID " +
                             "JOIN Section sec ON cs.SectionID = sec.SectionID " +
                             "WHERE tc.TeacherID = ?"
             )) {
            stmt.setString(1, cTeacher.getTeacherID());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new AssignedCoursesRow(
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getString("SemesterName"),
                        rs.getString("SectionName")
                ));
            }
            tableAssignedCourses.setItems(list);
        } catch (Exception e) {
            showAlert("Error loading assigned courses: " + e.getMessage());
        }
    }

    @FXML
    private void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 600, 420));
            TeacherDashBoard controller = loader.getController();
            controller.setTeacher(cTeacher);
        } catch (Exception e) {
            showAlert("Navigation failed: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.showAndWait();
    }
}
