package com.example.studentmanagementsystem.DashBoards.Student.Transcript;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.DashBoards.Student.StudentDashBoard;
import com.example.studentmanagementsystem.Models.Student;
import com.example.studentmanagementsystem.Models.TranscriptRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.sql.*;

public class TranscriptController {

    @FXML private Label lblName, lblEnrollment, lblProgram, lblCGPA, lblTotalCredits;
    @FXML private TableView<TranscriptRow> tableTranscript;
    @FXML private TableColumn<TranscriptRow, String> colSemester, colCourseCode, colCourseName, colGrade, colStatus;
    @FXML private TableColumn<TranscriptRow, Integer> colCreditHours;
    @FXML private TableColumn<TranscriptRow, Double> colGPA;
    @FXML private Button btnDownload, btnGoBack;

    Student cStudent;

    public void setStudent(Student s) {
        this.cStudent = s;
        loadStudentInfo();
        loadTranscript();
    }

    @FXML
    public void initialize() {
        colSemester.setCellValueFactory(data -> data.getValue().semesterNameProperty());
        colCourseCode.setCellValueFactory(data -> data.getValue().courseCodeProperty());
        colCourseName.setCellValueFactory(data -> data.getValue().courseNameProperty());
        colCreditHours.setCellValueFactory(data -> data.getValue().creditHoursProperty().asObject());
        colGrade.setCellValueFactory(data -> data.getValue().gradeProperty());
        colGPA.setCellValueFactory(data -> data.getValue().gpaProperty().asObject());
        colStatus.setCellValueFactory(data -> data.getValue().statusProperty());
    }

    private void loadStudentInfo() {
        if (cStudent == null) return;
        lblName.setText(cStudent.getName());
        lblEnrollment.setText(cStudent.getEnrollment());

        // You may fetch program/department here if you want more accurate info
        lblProgram.setText("BS Computer Science"); // or dynamically from DB
    }

    private void loadTranscript() {
        ObservableList<TranscriptRow> rows = FXCollections.observableArrayList();
        double totalPoints = 0;
        int totalCredits = 0;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT s.SemesterName, c.CourseCode, c.CourseName, c.CreditHours, sg.Grade, sg.Status " +
                    "FROM StudentGrade sg " +
                    "JOIN Course c ON sg.CourseID = c.CourseID " +
                    "JOIN Semester s ON sg.SemesterID = s.SemesterID " +
                    "WHERE sg.Enrollment = ? " +
                    "ORDER BY s.Year, s.SemesterName";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, cStudent.getEnrollment());
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    String semester = rs.getString("SemesterName");
                    String courseCode = rs.getString("CourseCode");
                    String courseName = rs.getString("CourseName");
                    int credits = rs.getInt("CreditHours");
                    String grade = rs.getString("Grade");
                    String status = rs.getString("Status");
                    double gpaPoint = getGpaPoint(grade);

                    if (grade != null && !grade.isEmpty() && !"In Progress".equalsIgnoreCase(status)) {
                        totalPoints += gpaPoint * credits;
                        totalCredits += credits;
                    }

                    rows.add(new TranscriptRow(
                            semester,
                            courseCode,
                            courseName,
                            credits,
                            grade == null ? "-" : grade,
                            gpaPoint,
                            status
                    ));
                }
            }
        } catch (Exception e) {
            showAlert("Load Failed", "Could not load transcript: " + e.getMessage(), Alert.AlertType.ERROR);
        }

        tableTranscript.setItems(rows);

        // CGPA
        double cgpa = totalCredits > 0 ? totalPoints / totalCredits : 0.0;
        lblCGPA.setText(String.format("%.2f", cgpa));
        lblTotalCredits.setText(String.valueOf(totalCredits));
    }

    private double getGpaPoint(String grade) {
        // Typical conversion, adjust as per your university's scale!
        if (grade == null) return 0.0;
        switch (grade.toUpperCase()) {
            case "A+": case "A":   return 4.0;
            case "A-":             return 3.7;
            case "B+":             return 3.3;
            case "B":              return 3.0;
            case "B-":             return 2.7;
            case "C+":             return 2.3;
            case "C":              return 2.0;
            case "C-":             return 1.7;
            case "D+":             return 1.3;
            case "D":              return 1.0;
            case "F":              return 0.0;
            default:               return 0.0;
        }
    }

    @FXML
    private void handleDownload() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Download Transcript PDF");
        fileChooser.setInitialFileName("Transcript.pdf");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        Stage stage = (Stage) btnDownload.getScene().getWindow();
        java.io.File file = fileChooser.showSaveDialog(stage);
        if (file == null) return;

        try {
            Document doc = new Document(PageSize.A4.rotate());
            PdfWriter.getInstance(doc, new FileOutputStream(file));
            doc.open();

            Font titleFont = new Font(Font.HELVETICA, 20, Font.BOLD);
            Paragraph title = new Paragraph("Official Academic Transcript\n\n", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            doc.add(title);

            Font infoFont = new Font(Font.HELVETICA, 14, Font.NORMAL);
            doc.add(new Paragraph("Name: " + lblName.getText(), infoFont));
            doc.add(new Paragraph("Enrollment: " + lblEnrollment.getText(), infoFont));
            doc.add(new Paragraph("Program: " + lblProgram.getText(), infoFont));
            doc.add(new Paragraph(" ")); // spacing

            PdfPTable table = new PdfPTable(7);
            table.setWidthPercentage(100);
            String[] headers = {"Semester", "Course Code", "Course Name", "Credits", "Grade", "GPA Points", "Status"};
            for (String h : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(h, new Font(Font.HELVETICA, 12, Font.BOLD)));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
            }

            for (TranscriptRow row : tableTranscript.getItems()) {
                table.addCell(row.getSemesterName());
                table.addCell(row.getCourseCode());
                table.addCell(row.getCourseName());
                table.addCell(String.valueOf(row.getCreditHours()));
                table.addCell(row.getGrade());
                table.addCell(String.format("%.2f", row.getGpa()));
                table.addCell(row.getStatus());
            }
            doc.add(table);

            // Summary
            doc.add(new Paragraph(" "));
            doc.add(new Paragraph("CGPA: " + lblCGPA.getText() + "   Total Credits: " + lblTotalCredits.getText(), infoFont));

            doc.close();
            showAlert("Download Complete", "Transcript PDF saved!", Alert.AlertType.INFORMATION);

        } catch (Exception e) {
            showAlert("Download Error", "Could not save PDF: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleGoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 600, 400));
            StudentDashBoard controller = loader.getController();
            controller.setStudentProfile(cStudent);
        } catch (Exception e) {
            showAlert("Navigation Failed", "Could not go back: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String msg, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
