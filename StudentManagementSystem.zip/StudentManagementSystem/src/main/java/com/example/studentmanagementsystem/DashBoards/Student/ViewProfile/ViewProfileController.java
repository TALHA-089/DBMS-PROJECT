package com.example.studentmanagementsystem.DashBoards.Student.ViewProfile;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.Models.Student;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewProfileController {
    @FXML private TextField tfEnrollment, tfName, tfEmail, tfPhone, tfBatch, tfSection;
    @FXML private PasswordField tfPassword;
    @FXML private Button btnSave, btnGoBack;

    private Student cStudent;

    public void setStudent(Student s) {
        this.cStudent = s;
        loadStudentProfile();
    }

    @FXML
    public void initialize() {
        // Will be filled when setStudent() is called after loading.
    }

    // Load student info into form fields
    private void loadStudentProfile() {
        if (cStudent == null) return;
        tfEnrollment.setText(cStudent.getEnrollment());
        tfName.setText(cStudent.getName());
        tfEmail.setText(cStudent.getEmail());
        tfPhone.setText(cStudent.getPhone());
        tfPassword.setText(cStudent.getPassword());

        // Fetch Batch and Section names (assuming IDs are present in cStudent)
        try (Connection conn = DBConnection.getConnection()) {
            // Batch Name
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT BatchName FROM Batch WHERE BatchID = ?")) {
                ps.setInt(1, cStudent.getBatchId());
                ResultSet rs = ps.executeQuery();
                tfBatch.setText(rs.next() ? rs.getString(1) : "N/A");
            }
            // Section Name
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT SectionName FROM Section WHERE SectionID = ?")) {
                ps.setInt(1, cStudent.getSectionId());
                ResultSet rs = ps.executeQuery();
                tfSection.setText(rs.next() ? rs.getString(1) : "N/A");
            }
        } catch (Exception e) {
            tfBatch.setText("N/A");
            tfSection.setText("N/A");
        }
    }

    @FXML
    private void handleSaveChanges() {
        String newName = tfName.getText().trim();
        String newEmail = tfEmail.getText().trim();
        String newPhone = tfPhone.getText().trim();
        String newPassword = tfPassword.getText().trim();

        if (newName.isEmpty() || newEmail.isEmpty() || newPhone.isEmpty() || newPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please fill all editable fields.");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE Student SET Name=?, Email=?, Phone=?, Password=? WHERE Enrollment=?")) {
            stmt.setString(1, newName);
            stmt.setString(2, newEmail);
            stmt.setString(3, newPhone);
            stmt.setString(4, newPassword);
            stmt.setString(5, cStudent.getEnrollment());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Profile updated successfully!");
                // Update local student object for session
                cStudent.setName(newName);
                cStudent.setEmail(newEmail);
                cStudent.setPhone(newPhone);
                cStudent.setPassword(newPassword);
            } else {
                showAlert(Alert.AlertType.ERROR, "Update Failed", "Profile update failed.");
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "DB Error", "Could not update profile:\n" + e.getMessage());
        }
    }

    @FXML
    private void handleGoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 400);
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            // Pass student back to dashboard
            com.example.studentmanagementsystem.DashBoards.Student.StudentDashBoard controller = loader.getController();
            controller.setStudentProfile(cStudent);
            stage.setScene(scene);
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not go back: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
