package com.example.studentmanagementsystem.Models;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class StudentAnalyticsRow {
    private final StringProperty studentName;
    private final StringProperty enrollment;
    private final StringProperty gpaOrCredits;

    public StudentAnalyticsRow(String name, String enroll, String val) {
        this.studentName = new SimpleStringProperty(name);
        this.enrollment = new SimpleStringProperty(enroll);
        this.gpaOrCredits = new SimpleStringProperty(val);
    }

    public StringProperty studentNameProperty() { return studentName; }
    public StringProperty enrollmentProperty() { return enrollment; }
    public StringProperty gpaOrCreditsProperty() { return gpaOrCredits; }
}
