package com.example.studentmanagementsystem.Models;

import javafx.beans.binding.BooleanExpression;
import javafx.beans.property.*;

public class SemesterRow {
    private final IntegerProperty semesterId;
    private final StringProperty semesterName;
    private final StringProperty year;
    private final StringProperty status;

    public SemesterRow(int semesterId, String semesterName, String year, String status) {
        this.semesterId = new SimpleIntegerProperty(semesterId);
        this.semesterName = new SimpleStringProperty(semesterName);
        this.year = new SimpleStringProperty(year);
        this.status = new SimpleStringProperty(status);
    }
    public int getSemesterId() { return semesterId.get(); }
    public StringProperty semesterNameProperty() { return semesterName; }
    public StringProperty yearProperty() { return year; }
    public StringProperty statusProperty() { return status; }
    public String getSemesterName() { return semesterName.get(); }
    public String getYear() { return year.get(); }
    public String getStatus() { return status.get(); }
    public IntegerProperty semesterIdProperty() {
        return semesterId;
    }

}
