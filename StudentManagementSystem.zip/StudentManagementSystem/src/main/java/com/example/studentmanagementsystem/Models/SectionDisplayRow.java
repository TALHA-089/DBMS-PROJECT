package com.example.studentmanagementsystem.Models;

public class SectionDisplayRow {
    private int sectionID;
    private String sectionName;
    private String batchName;
    private String departmentName;

    public SectionDisplayRow(int sectionID, String sectionName, String batchName, String departmentName) {
        this.sectionID = sectionID;
        this.sectionName = sectionName;
        this.batchName = batchName;
        this.departmentName = departmentName;
    }

    public int getSectionID() { return sectionID; }
    public String getSectionName() { return sectionName; }
    public String getBatchName() { return batchName; }
    public String getDepartmentName() { return departmentName; }
}
