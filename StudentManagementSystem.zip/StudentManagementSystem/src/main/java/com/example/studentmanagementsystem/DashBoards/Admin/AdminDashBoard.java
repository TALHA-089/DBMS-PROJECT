package com.example.studentmanagementsystem.DashBoards.Admin;

import com.example.studentmanagementsystem.CMS;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;

public class AdminDashBoard {

    private void loadScene(String fxmlPath, String title, int width, int height) {
        try {
            Stage stage = (Stage) Stage.getWindows().filtered(Window::isShowing).getFirst();
            FXMLLoader fxmlLoader = new FXMLLoader(CMS.class.getResource(fxmlPath));
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            stage.setScene(scene);
            stage.setTitle(title);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Unable to load " + title + " screen.");
        }
    }

    // Core Features
    @FXML public void goToStudents() {
        loadScene("/FXMLS/ManageStudents/Students.fxml", "Manage Students", 900, 694);
    }

    @FXML public void goToTeachers() {
        loadScene("/FXMLS/ManageTeachers/ManageTeachers.fxml", "Manage Teachers", 900, 600);
    }

    @FXML public void goToCourses() {
        loadScene("/FXMLS/ManageCourses/ManageCourses.fxml", "Manage Courses", 900, 600);
    }

    @FXML public void goToDepartments() {
        loadScene("/FXMLS/ManageDepartments/ManageDepartments.fxml", "Manage Departments", 600, 400);
    }

    @FXML public void goToSections() {
        loadScene("/FXMLS/ManageSections/ManageSections.fxml", "Manage Sections", 700, 450);
    }

    @FXML public void goToFloors() {
        loadScene("/FXMLS/ManageFloors/ManageFloors.fxml", "Manage Floors", 600, 370);
    }

    @FXML public void goToTimeTable() {
        loadScene("/FXMLS/ManageTimeTable/TimeTable.fxml", "TimeTable Management", 1100, 600);
    }

    @FXML public void goToRooms() {
        loadScene("/FXMLS/ManageRooms/ManageRooms.fxml", "Manage Rooms", 750, 420);
    }

    // Additional Features
    @FXML public void goToSemesters() {
        loadScene("/FXMLS/ManageSemester/ManageSemester.fxml", "Manage Semester", 600, 400);
    }

    @FXML public void goToBatchwiseFilters() {
        loadScene("/FXMLS/BatchWiseFilters/BatchwiseFilters.fxml", "Batchwise Filters", 800, 522);
    }

    // Sign out
    @FXML public void SignOut() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Sign Out");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to sign out?");
        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            try {
                Stage stage = (Stage) Stage.getWindows().filtered(Window::isShowing).getFirst();
                FXMLLoader fxmlLoader = new FXMLLoader(CMS.class.getResource("/FXMLS/CMS.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 470);
                stage.setScene(scene);
                stage.setTitle("Login Page");
                stage.setResizable(false);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Error", "Unable to return to login screen.");
            }
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
