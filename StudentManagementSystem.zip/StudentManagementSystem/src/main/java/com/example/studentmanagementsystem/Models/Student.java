package com.example.studentmanagementsystem.Models;
public class Student {
    private String enrollment;
    private String name;
    private String password;
    private String email;
    private String phone;
    private int batchId;
    private int sectionId;

    public Student(String enrollment, String name, String password, String email, String phone, int batchId, int sectionId) {
        this.enrollment = enrollment;
        this.name = name;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.batchId = batchId;
        this.sectionId = sectionId;
    }

    public String getEnrollment() {
        return enrollment;
    }

    public void setEnrollment(String enrollment) {
        this.enrollment = enrollment;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public int getSectionId() {
        return sectionId;
    }

    public void setSectionId(int sectionId) {
        this.sectionId = sectionId;
    }
}
