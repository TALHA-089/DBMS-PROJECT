package com.example.studentmanagementsystem.Models;

public class TimetableDisplayRow {
    private int timetableID;
    private String day;
    private String startTime, endTime;
    private String courseCode, courseName;
    private String section;
    private String teacher;
    private String room;
    private String floor;
    private String roomType;

    public TimetableDisplayRow(int timetableID, String day, String startTime, String endTime,
                               String courseCode, String courseName, String section, String teacher,
                               String room, String floor, String roomType) {
        this.timetableID = timetableID;
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.section = section;
        this.teacher = teacher;
        this.room = room;
        this.floor = floor;
        this.roomType = roomType;
    }

    public int getTimetableID() { return timetableID; }
    public String getDay() { return day; }
    public String getStartTime() { return startTime; }
    public String getEndTime() { return endTime; }
    public String getCourseCode() { return courseCode; }
    public String getCourseName() { return courseName; }
    public String getSection() { return section; }
    public String getTeacher() { return teacher; }
    public String getRoom() { return room; }
    public String getFloor() { return floor; }
    public String getRoomType() { return roomType; }
}
