package com.example.studentmanagementsystem.DashBoards.Student.GPACalculator;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.Student;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

public class GPACalculatorController {
    Student cStudent;
    public void setStudent(Student s){
        cStudent=s;
    }

    @FXML private Spinner<Integer> spnCourseCount;
    @FXML private Button btnGenerateRows, btnCalculate, btnGoBack;
    @FXML private TableView<GPARow> tableCourses;
    @FXML private TableColumn<GPARow, String> colCourse, colGrade;
    @FXML private TableColumn<GPARow, Integer> colCredits;
    @FXML private Label lblResult;

    private final ObservableList<GPARow> courses = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Setup Spinner
        if (spnCourseCount != null) {
            spnCourseCount.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 12, 5));
        }

        // Table columns
        colCourse.setCellValueFactory(data -> new SimpleStringProperty("Course " + (courses.indexOf(data.getValue())+1)));
        colGrade.setCellValueFactory(cellData -> cellData.getValue().gradeProperty());
        colGrade.setCellFactory(TextFieldTableCell.forTableColumn());
        colGrade.setOnEditCommit(event -> event.getRowValue().setGrade(event.getNewValue()));

        colCredits.setCellValueFactory(cellData -> cellData.getValue().creditHoursProperty().asObject());
        colCredits.setCellFactory(TextFieldTableCell.forTableColumn(new javafx.util.converter.IntegerStringConverter()));
        colCredits.setOnEditCommit(event -> {
            try {
                int credits = Integer.parseInt(event.getNewValue()+"");
                if (credits < 0) throw new NumberFormatException();
                event.getRowValue().setCreditHours(credits);
            } catch (Exception e) {
                showResult("Credit hours must be a positive integer.", true);
                tableCourses.refresh();
            }
        });

        tableCourses.setEditable(true);
        tableCourses.setItems(courses);

        btnGenerateRows.setOnAction(e -> generateRows());
        btnCalculate.setOnAction(e -> calculateGPA());

        if (btnGoBack != null) {
            btnGoBack.setOnAction(e -> goBack());
        }

        generateRows(); // Initial table
    }

    private void generateRows() {
        int count = spnCourseCount.getValue();
        courses.clear();
        for (int i = 0; i < count; i++)
            courses.add(new GPARow("", 0));
        lblResult.setText("");
    }

    private void calculateGPA() {
        double totalQualityPoints = 0;
        int totalCredits = 0;
        for (GPARow row : courses) {
            String grade = row.getGrade().trim().toUpperCase();
            int credits = row.getCreditHours();
            if (grade.isEmpty()) {
                showResult("Please fill all grades.", true);
                return;
            }
            if (credits <= 0) {
                showResult("Credit hours must be > 0.", true);
                return;
            }
            double gradePoint = getGradePoint(grade);
            if (gradePoint < 0) {
                showResult("Invalid grade: " + grade + ". Use (A+, A, B+, ... F)", true);
                return;
            }
            totalQualityPoints += gradePoint * credits;
            totalCredits += credits;
        }
        if (totalCredits == 0) {
            showResult("Total credits must be greater than 0.", true);
            return;
        }
        double gpa = totalQualityPoints / totalCredits;
        showResult(String.format("GPA: %.2f", gpa), false);
    }

    private double getGradePoint(String grade) {
        switch (grade) {
            case "A+": return 4.0;
            case "A": return 4.0;
            case "A-": return 3.7;
            case "B+": return 3.3;
            case "B": return 3.0;
            case "B-": return 2.7;
            case "C+": return 2.3;
            case "C": return 2.0;
            case "C-": return 1.7;
            case "D+": return 1.3;
            case "D": return 1.0;
            case "F": return 0.0;
            default: return -1.0; // invalid
        }
    }

    private void showResult(String msg, boolean error) {
        lblResult.setText(msg);
        lblResult.setStyle(error
                ? "-fx-font-size: 18px; -fx-text-fill: #c91c1c; -fx-font-weight: bold;"
                : "-fx-font-size: 22px; -fx-text-fill: #003700; -fx-font-weight: bold;");
    }

    private void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 400);
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            // Pass student back to dashboard
            com.example.studentmanagementsystem.DashBoards.Student.StudentDashBoard controller = loader.getController();
            controller.setStudentProfile(cStudent);
            stage.setScene(scene);
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not go back: " + e.getMessage());
        }
    }

    // GPA Table Row Model
    public static class GPARow {
        private final SimpleStringProperty grade = new SimpleStringProperty("");
        private final SimpleIntegerProperty creditHours = new SimpleIntegerProperty(0);

        public GPARow(String grade, int creditHours) {
            this.grade.set(grade);
            this.creditHours.set(creditHours);
        }
        public String getGrade() { return grade.get(); }
        public void setGrade(String g) { grade.set(g); }
        public SimpleStringProperty gradeProperty() { return grade; }
        public int getCreditHours() { return creditHours.get(); }
        public void setCreditHours(int c) { creditHours.set(c); }
        public SimpleIntegerProperty creditHoursProperty() { return creditHours; }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
