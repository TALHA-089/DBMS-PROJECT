package com.example.studentmanagementsystem.Models;

public class Section {
    private int sectionID;
    private String sectionName;

    public Section(int sectionID, String sectionName) {
        this.sectionID = sectionID;
        this.sectionName = sectionName;
    }

    public int getSectionID() {
        return sectionID;
    }

    public String getSectionName() {
        return sectionName;
    }

    @Override
    public String toString() {
        return sectionName; // for ComboBox display
    }
}
