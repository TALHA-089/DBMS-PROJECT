package com.example.studentmanagementsystem.DashBoards.Student.ViewTimeTable;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.DashBoards.Student.StudentDashBoard;
import com.example.studentmanagementsystem.Models.Student;
import com.example.studentmanagementsystem.Models.TimetableDisplayRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.*;

public class ViewTimeTableController {

    @FXML private TableView<TimetableDisplayRow> tableTimeTable;
    @FXML private TableColumn<TimetableDisplayRow, String> colDay, colStartTime, colEndTime,
            colCourseCode, colCourseName, colSection, colTeacher, colRoom, colRoomType;
    @FXML private Label lblStatus;
    @FXML private Button btnGoBack;

    private Student cStudent;

    public void setStudent(Student s) {
        this.cStudent = s;
        loadTimeTable();
    }

    @FXML
    public void initialize() {
        colDay.setCellValueFactory(new PropertyValueFactory<>("day"));
        colStartTime.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        colEndTime.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        colCourseCode.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        colCourseName.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        colSection.setCellValueFactory(new PropertyValueFactory<>("section"));
        colTeacher.setCellValueFactory(new PropertyValueFactory<>("teacher"));
        colRoom.setCellValueFactory(new PropertyValueFactory<>("room"));
        colRoomType.setCellValueFactory(new PropertyValueFactory<>("roomType"));

    }

    private void loadTimeTable() {
        if (cStudent == null) {
            lblStatus.setText("Student not set.");
            return;
        }
        ObservableList<TimetableDisplayRow> rows = FXCollections.observableArrayList();

        // Fetch the section for the student
        int sectionId = cStudent.getSectionId();

        String sql = "SELECT t.DayOfWeek, t.StartTime, t.EndTime, " +
                "c.CourseCode, c.CourseName, s.SectionName, te.Name as Teacher, " +
                "CONCAT(f.FloorNumber, '-', r.RoomNumber) as Room, r.RoomType " +
                "FROM Timetable t " +
                "JOIN Course c ON t.CourseID = c.CourseID " +
                "JOIN Section s ON t.SectionID = s.SectionID " +
                "JOIN Teacher te ON t.TeacherID = te.TeacherID " +
                "JOIN Room r ON t.RoomID = r.RoomID " +
                "JOIN Floor f ON r.FloorID = f.FloorID " +
                "WHERE t.SectionID = ? " +
                "ORDER BY FIELD(t.DayOfWeek, 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), t.StartTime";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, sectionId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rows.add(new TimetableDisplayRow(
                        0,
                        rs.getString("DayOfWeek"),
                        rs.getString("StartTime"),
                        rs.getString("EndTime"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getString("SectionName"),
                        rs.getString("Teacher"),
                        rs.getString("Room"),
                        "", // Floor (not shown in UI)
                        rs.getString("RoomType")
                ));
            }
            tableTimeTable.setItems(rows);
            lblStatus.setText(rows.isEmpty() ? "No timetable found for your section." : "");
        } catch (SQLException e) {
            lblStatus.setText("Database error: " + e.getMessage());
        }
    }

    @FXML
    private void handleGoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 400);
            StudentDashBoard dash = loader.getController();
            dash.setStudentProfile(cStudent);
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            lblStatus.setText("Could not go back: " + e.getMessage());
        }
    }
}
