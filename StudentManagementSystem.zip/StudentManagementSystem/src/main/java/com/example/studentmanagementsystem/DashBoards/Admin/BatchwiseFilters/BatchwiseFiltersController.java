package com.example.studentmanagementsystem.DashBoards.Admin.BatchwiseFilters;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.Models.StudentAnalyticsRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.*;

public class BatchwiseFiltersController {

    @FXML private ComboBox<String> cbBatch;
    @FXML private ComboBox<String> cbGpaRange;
    @FXML private Button btnGpaFilter, btnCreditFilter, GoBack;
    @FXML private TableView<StudentAnalyticsRow> tableResults;
    @FXML private TableColumn<StudentAnalyticsRow, String> colStudentName, colEnrollment, colGpaOrCredits;

    @FXML
    public void initialize() {
        // Setup Table columns
        colStudentName.setCellValueFactory(data -> data.getValue().studentNameProperty());
        colEnrollment.setCellValueFactory(data -> data.getValue().enrollmentProperty());
        colGpaOrCredits.setCellValueFactory(data -> data.getValue().gpaOrCreditsProperty());

        // Populate batch ComboBox
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DISTINCT BatchName FROM Batch")) {
            ObservableList<String> batches = FXCollections.observableArrayList();
            while (rs.next()) {
                batches.add(rs.getString("BatchName"));
            }
            cbBatch.setItems(batches);
        } catch (Exception e) {
            showAlert("Error loading batches: " + e.getMessage());
        }

        // GPA Range presets
        cbGpaRange.setItems(FXCollections.observableArrayList(
                "< 2.0", "2.0 - 3.0", "> 3.0"
        ));
    }

    @FXML
    private void handleShowGpaList() {
        String batch = cbBatch.getValue();
        String gpaRange = cbGpaRange.getValue();
        if (batch == null || gpaRange == null) {
            showAlert("Select both Batch and GPA range.");
            return;
        }
        // Parse GPA Range
        String havingClause = "";
        if (gpaRange.equals("< 2.0")) havingClause = "HAVING GPA < 2.0";
        else if (gpaRange.equals("2.0 - 3.0")) havingClause = "HAVING GPA >= 2.0 AND GPA <= 3.0";
        else if (gpaRange.equals("> 3.0")) havingClause = "HAVING GPA > 3.0";

        String sql = """
            SELECT s.Name, s.Enrollment, 
                ROUND(SUM(
                    CASE 
                        WHEN sg.Grade IS NOT NULL THEN 
                            CASE sg.Grade 
                                WHEN 'A' THEN 4.0 WHEN 'A-' THEN 3.7 WHEN 'B+' THEN 3.3
                                WHEN 'B' THEN 3.0 WHEN 'B-' THEN 2.7 WHEN 'C+' THEN 2.3
                                WHEN 'C' THEN 2.0 WHEN 'C-' THEN 1.7 WHEN 'D' THEN 1.0
                                ELSE 0.0 END 
                        ELSE 0.0 END * c.CreditHours) / NULLIF(SUM(c.CreditHours), 0), 2) AS GPA
            FROM Student s
            JOIN Batch b ON s.BatchID = b.BatchID
            JOIN StudentGrade sg ON s.Enrollment = sg.Enrollment
            JOIN Course c ON sg.CourseID = c.CourseID
            WHERE b.BatchName = ?
            GROUP BY s.Enrollment
            %s
            """.formatted(havingClause);

        ObservableList<StudentAnalyticsRow> rows = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, batch);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rows.add(new StudentAnalyticsRow(
                        rs.getString("Name"),
                        rs.getString("Enrollment"),
                        rs.getString("GPA")
                ));
            }
            tableResults.setItems(rows);
            colGpaOrCredits.setText("GPA");
        } catch (Exception e) {
            showAlert("DB Error: " + e.getMessage());
        }
    }

    @FXML
    private void handleShowCreditHours() {
        String batch = cbBatch.getValue();
        if (batch == null) {
            showAlert("Select Batch.");
            return;
        }
        String sql = """
            SELECT s.Name, s.Enrollment, SUM(c.CreditHours) AS CompletedCredits
            FROM Student s
            JOIN Batch b ON s.BatchID = b.BatchID
            JOIN StudentGrade sg ON s.Enrollment = sg.Enrollment
            JOIN Course c ON sg.CourseID = c.CourseID
            WHERE b.BatchName = ?
              AND sg.Status = 'Completed'
            GROUP BY s.Enrollment
            """;
        ObservableList<StudentAnalyticsRow> rows = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, batch);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rows.add(new StudentAnalyticsRow(
                        rs.getString("Name"),
                        rs.getString("Enrollment"),
                        rs.getString("CompletedCredits")
                ));
            }
            tableResults.setItems(rows);
            colGpaOrCredits.setText("Completed Credits");
        } catch (Exception e) {
            showAlert("DB Error: " + e.getMessage());
        }
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.showAndWait();
    }
}
