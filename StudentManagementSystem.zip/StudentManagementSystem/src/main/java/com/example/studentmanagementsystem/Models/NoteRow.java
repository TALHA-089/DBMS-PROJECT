package com.example.studentmanagementsystem.Models;

import javafx.beans.property.*;

import java.sql.Timestamp;

public class NoteRow {
    private final IntegerProperty noteId;
    private final StringProperty fileName, fileType, uploadDate;
    public NoteRow(int noteId, String fileName, String fileType, Timestamp uploadDate) {
        this.noteId = new SimpleIntegerProperty(noteId);
        this.fileName = new SimpleStringProperty(fileName);
        this.fileType = new SimpleStringProperty(fileType);
        this.uploadDate = new SimpleStringProperty(uploadDate.toString());
    }
    public int getNoteId() { return noteId.get(); }
    public String getFileName() { return fileName.get(); }
    public String getFileType() { return fileType.get(); }
    public String getUploadDate() { return uploadDate.get(); }
    public IntegerProperty noteIdProperty() { return noteId; }
    public StringProperty fileNameProperty() { return fileName; }
    public StringProperty fileTypeProperty() { return fileType; }
    public StringProperty uploadDateProperty() { return uploadDate; }
}
