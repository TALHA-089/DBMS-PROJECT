package com.example.studentmanagementsystem.DashBoards.Admin.ManageTimeTable;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.TimetableDisplayRow;
import com.example.studentmanagementsystem.DBconnection.DBConnection;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.sql.*;
import java.util.List;
import java.util.Optional;

public class ManageTimeTableController {

    @FXML private TableView<TimetableDisplayRow> tableTimetable;
    @FXML private TableColumn<TimetableDisplayRow, String> colDay, colStartTime, colEndTime, colCourseCode,
            colCourseName, colSection, colTeacher, colRoom, colFloor, colRoomType;
    @FXML private ComboBox<String> cbSection, cbTeacher, cbRoom, cbDay;
    @FXML private Button btnGenerate, btnAdd, btnEdit, btnDelete, btnClearFilters;
    @FXML private ImageView GoBack;

    private ObservableList<TimetableDisplayRow> allRows = FXCollections.observableArrayList();
    private int selectedTimetableID = -1;

    @FXML
    public void initialize() {
        colDay.setCellValueFactory(new PropertyValueFactory<>("day"));
        colStartTime.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        colEndTime.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        colCourseCode.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        colCourseName.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        colSection.setCellValueFactory(new PropertyValueFactory<>("section"));
        colTeacher.setCellValueFactory(new PropertyValueFactory<>("teacher"));
        colRoom.setCellValueFactory(new PropertyValueFactory<>("room"));
        colFloor.setCellValueFactory(new PropertyValueFactory<>("floor"));
        colRoomType.setCellValueFactory(new PropertyValueFactory<>("roomType"));

        loadFilters();
        loadTimetable();

        cbSection.setOnAction(this::cbFilterChanged);
        cbTeacher.setOnAction(this::cbFilterChanged);
        cbRoom.setOnAction(this::cbFilterChanged);
        cbDay.setOnAction(this::cbFilterChanged);

        tableTimetable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) selectedTimetableID = newSel.getTimetableID();
            else selectedTimetableID = -1;
        });
    }

    private void loadFilters() {
        cbSection.setItems(getFieldList("Section", "SectionName"));
        cbTeacher.setItems(getFieldList("Teacher", "Name"));
        cbRoom.setItems(getRoomCodes());
        cbDay.setItems(FXCollections.observableArrayList(
                "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
        ));
    }

    private void loadTimetable() {
        allRows.clear();
        String query = "SELECT t.TimetableID, t.DayOfWeek, t.StartTime, t.EndTime, c.CourseCode, c.CourseName, " +
                "s.SectionName, te.Name as TeacherName, f.FloorNumber, r.RoomNumber, r.RoomType " +
                "FROM Timetable t " +
                "JOIN Course c ON t.CourseID = c.CourseID " +
                "JOIN Section s ON t.SectionID = s.SectionID " +
                "JOIN Teacher te ON t.TeacherID = te.TeacherID " +
                "JOIN Room r ON t.RoomID = r.RoomID " +
                "JOIN Floor f ON r.FloorID = f.FloorID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                allRows.add(new TimetableDisplayRow(
                        rs.getInt("TimetableID"),
                        rs.getString("DayOfWeek"),
                        rs.getString("StartTime"),
                        rs.getString("EndTime"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getString("SectionName"),
                        rs.getString("TeacherName"),
                        rs.getInt("FloorNumber") + "-" + rs.getInt("RoomNumber"),
                        String.valueOf(rs.getInt("FloorNumber")),
                        rs.getString("RoomType")
                ));
            }
            tableTimetable.setItems(FXCollections.observableArrayList(allRows));
        } catch (SQLException e) {
            showAlert("Failed to load timetable: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleClearFilters(ActionEvent event) {
        cbSection.getSelectionModel().clearSelection();
        cbTeacher.getSelectionModel().clearSelection();
        cbRoom.getSelectionModel().clearSelection();
        cbDay.getSelectionModel().clearSelection();
        tableTimetable.setItems(FXCollections.observableArrayList(allRows));
    }

    @FXML
    private void cbFilterChanged(ActionEvent event) {
        ObservableList<TimetableDisplayRow> filtered = FXCollections.observableArrayList(allRows);
        if (cbSection.getValue() != null)
            filtered.removeIf(row -> !cbSection.getValue().equals(row.getSection()));
        if (cbTeacher.getValue() != null)
            filtered.removeIf(row -> !cbTeacher.getValue().equals(row.getTeacher()));
        if (cbRoom.getValue() != null)
            filtered.removeIf(row -> !cbRoom.getValue().equals(row.getRoom()));
        if (cbDay.getValue() != null)
            filtered.removeIf(row -> !cbDay.getValue().equals(row.getDay()));
        tableTimetable.setItems(filtered);
    }

    @FXML
    private void handleAddTimetableEntry(ActionEvent event) {
        var courses = getFieldList("Course", "CourseCode");
        var sections = getFieldList("Section", "SectionName");
        var teachers = getFieldList("Teacher", "Name");
        var rooms = getRoomCodes();
        var days = List.of("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
        var startTimes = List.of("08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00");
        var endTimes = List.of("09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00");

        TimetableEntryDialog dialog = new TimetableEntryDialog(
                courses, sections, teachers, rooms, days, startTimes, endTimes, null
        );
        Optional<TimetableEntryData> result = dialog.showAndWait();
        result.ifPresent(data -> {
            if (!data.isValid()) {
                showAlert("Fill all fields.", Alert.AlertType.WARNING);
                return;
            }
            if (isConflict(data.day, data.startTime, data.endTime, data.roomCode, data.teacherName, data.sectionName, null)) {
                showAlert("Clash detected (room, teacher, or section busy).", Alert.AlertType.ERROR);
                return;
            }
            int courseId = getID("Course", "CourseCode", data.courseCode);
            int sectionId = getID("Section", "SectionName", data.sectionName);
            String teacherId = getTeacherIDByName(data.teacherName);
            int roomId = getRoomIDByCode(data.roomCode);
            try (Connection conn = DBConnection.getConnection()) {
                String insert = "INSERT INTO Timetable (CourseID, TeacherID, SectionID, RoomID, DayOfWeek, StartTime, EndTime, IsLab) VALUES (?,?,?,?,?,?,?,?)";
                try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                    stmt.setInt(1, courseId);
                    stmt.setString(2, teacherId);
                    stmt.setInt(3, sectionId);
                    stmt.setInt(4, roomId);
                    stmt.setString(5, data.day);
                    stmt.setString(6, data.startTime);
                    stmt.setString(7, data.endTime);
                    stmt.setBoolean(8, false); // Set for lab if you want
                    stmt.executeUpdate();
                    showAlert("Entry added.", Alert.AlertType.INFORMATION);
                    loadTimetable();
                }
            } catch (SQLException e) {
                showAlert("DB insert failed: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        });
    }

    @FXML
    private void handleEditTimetableEntry(ActionEvent event) {
        if (selectedTimetableID == -1) {
            showAlert("Select a timetable entry to edit.", Alert.AlertType.WARNING);
            return;
        }
        TimetableDisplayRow row = tableTimetable.getSelectionModel().getSelectedItem();

        var courses = getFieldList("Course", "CourseCode");
        var sections = getFieldList("Section", "SectionName");
        var teachers = getFieldList("Teacher", "Name");
        var rooms = getRoomCodes();
        var days = List.of("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
        var startTimes = List.of("08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00");
        var endTimes = List.of("09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00");

        TimetableEntryData init = new TimetableEntryData(
                row.getCourseCode(), row.getSection(), row.getTeacher(), row.getRoom(), row.getDay(), row.getStartTime(), row.getEndTime()
        );
        TimetableEntryDialog dialog = new TimetableEntryDialog(
                courses, sections, teachers, rooms, days, startTimes, endTimes, init
        );
        Optional<TimetableEntryData> result = dialog.showAndWait();
        result.ifPresent(data -> {
            if (!data.isValid()) {
                showAlert("Fill all fields.", Alert.AlertType.WARNING);
                return;
            }
            if (isConflict(data.day, data.startTime, data.endTime, data.roomCode, data.teacherName, data.sectionName, selectedTimetableID)) {
                showAlert("Clash detected (room, teacher, or section busy).", Alert.AlertType.ERROR);
                return;
            }
            int courseId = getID("Course", "CourseCode", data.courseCode);
            int sectionId = getID("Section", "SectionName", data.sectionName);
            String teacherId = getTeacherIDByName(data.teacherName);
            int roomId = getRoomIDByCode(data.roomCode);
            try (Connection conn = DBConnection.getConnection()) {
                String update = "UPDATE Timetable SET CourseID=?, TeacherID=?, SectionID=?, RoomID=?, DayOfWeek=?, StartTime=?, EndTime=? WHERE TimetableID=?";
                try (PreparedStatement stmt = conn.prepareStatement(update)) {
                    stmt.setInt(1, courseId);
                    stmt.setString(2, teacherId);
                    stmt.setInt(3, sectionId);
                    stmt.setInt(4, roomId);
                    stmt.setString(5, data.day);
                    stmt.setString(6, data.startTime);
                    stmt.setString(7, data.endTime);
                    stmt.setInt(8, selectedTimetableID);
                    stmt.executeUpdate();
                    showAlert("Entry updated.", Alert.AlertType.INFORMATION);
                    loadTimetable();
                }
            } catch (SQLException e) {
                showAlert("DB update failed: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        });
    }

    @FXML
    private void handleDeleteTimetableEntry(ActionEvent event) {
        if (selectedTimetableID == -1) {
            showAlert("Select a timetable entry to delete.", Alert.AlertType.WARNING);
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String delete = "DELETE FROM Timetable WHERE TimetableID=?";
            try (PreparedStatement stmt = conn.prepareStatement(delete)) {
                stmt.setInt(1, selectedTimetableID);
                stmt.executeUpdate();
                showAlert("Entry deleted.", Alert.AlertType.INFORMATION);
                loadTimetable();
            }
        } catch (SQLException e) {
            showAlert("Delete failed: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // --- Helpers for ComboBox data ---
    private ObservableList<String> getFieldList(String table, String field) {
        ObservableList<String> list = FXCollections.observableArrayList();
        String sql = "SELECT " + field + " FROM " + table;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) list.add(rs.getString(1));
        } catch (SQLException e) {}
        return list;
    }

    private ObservableList<String> getRoomCodes() {
        ObservableList<String> list = FXCollections.observableArrayList();
        String sql = "SELECT f.FloorNumber, r.RoomNumber FROM Room r JOIN Floor f ON r.FloorID=f.FloorID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) list.add(rs.getInt(1) + "-" + rs.getInt(2));
        } catch (SQLException e) {}
        return list;
    }

    private int getID(String table, String field, String value) {
        String sql = "SELECT " + table + "ID FROM " + table + " WHERE " + field + "=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, value);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {}
        return -1;
    }

    private String getTeacherIDByName(String name) {
        String sql = "SELECT TeacherID FROM Teacher WHERE Name=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getString("TeacherID");
        } catch (SQLException e) {}
        return null;
    }

    private int getRoomIDByCode(String roomCode) {
        String[] parts = roomCode.split("-");
        int floorNum = Integer.parseInt(parts[0]);
        int roomNum = Integer.parseInt(parts[1]);
        String sql = "SELECT r.RoomID FROM Room r JOIN Floor f ON r.FloorID=f.FloorID WHERE f.FloorNumber=? AND r.RoomNumber=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, floorNum);
            stmt.setInt(2, roomNum);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {}
        return -1;
    }

    // --- Conflict checker ---
    private boolean isConflict(String day, String start, String end, String room, String teacher, String section, Integer excludeTimetableID) {
        String[] parts = room.split("-");
        int floorNum = Integer.parseInt(parts[0]);
        int roomNum = Integer.parseInt(parts[1]);
        String sql = "SELECT t.TimetableID FROM Timetable t " +
                "JOIN Room r ON t.RoomID = r.RoomID " +
                "JOIN Floor f ON r.FloorID = f.FloorID " +
                "JOIN Section s ON t.SectionID = s.SectionID " +
                "JOIN Teacher te ON t.TeacherID = te.TeacherID " +
                "WHERE t.DayOfWeek=? " +
                "AND ( " +
                "    (t.StartTime < ? AND t.EndTime > ?) " +
                ") " +
                (excludeTimetableID != null ? "AND t.TimetableID <> ? " : "") +
                "AND ( (r.RoomNumber=? AND f.FloorNumber=?) OR te.Name=? OR s.SectionName=? )";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, day);
            stmt.setString(2, end);
            stmt.setString(3, start);
            int idx = 4;
            if (excludeTimetableID != null) {
                stmt.setInt(idx++, excludeTimetableID);
            }
            stmt.setInt(idx++, roomNum);
            stmt.setInt(idx++, floorNum);
            stmt.setString(idx++, teacher);
            stmt.setString(idx, section);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) { return true; }
    }

    // --- Dialog Helper Classes ---
    private static class TimetableEntryDialog extends Dialog<TimetableEntryData> {
        public TimetableEntryDialog(
                List<String> courseCodes, List<String> sectionNames,
                List<String> teacherNames, List<String> rooms,
                List<String> days, List<String> startTimes, List<String> endTimes,
                TimetableEntryData initial
        ) {
            setTitle(initial == null ? "Add Timetable Entry" : "Edit Timetable Entry");
            GridPane grid = new GridPane();
            grid.setHgap(10); grid.setVgap(10);

            ComboBox<String> cbCourse = new ComboBox<>(FXCollections.observableArrayList(courseCodes));
            ComboBox<String> cbSection = new ComboBox<>(FXCollections.observableArrayList(sectionNames));
            ComboBox<String> cbTeacher = new ComboBox<>(FXCollections.observableArrayList(teacherNames));
            ComboBox<String> cbRoom = new ComboBox<>(FXCollections.observableArrayList(rooms));
            ComboBox<String> cbDay = new ComboBox<>(FXCollections.observableArrayList(days));
            ComboBox<String> cbStart = new ComboBox<>(FXCollections.observableArrayList(startTimes));
            ComboBox<String> cbEnd = new ComboBox<>(FXCollections.observableArrayList(endTimes));

            grid.add(new Label("Course:"), 0, 0); grid.add(cbCourse, 1, 0);
            grid.add(new Label("Section:"), 0, 1); grid.add(cbSection, 1, 1);
            grid.add(new Label("Teacher:"), 0, 2); grid.add(cbTeacher, 1, 2);
            grid.add(new Label("Room:"), 0, 3); grid.add(cbRoom, 1, 3);
            grid.add(new Label("Day:"), 0, 4); grid.add(cbDay, 1, 4);
            grid.add(new Label("Start Time:"), 0, 5); grid.add(cbStart, 1, 5);
            grid.add(new Label("End Time:"), 0, 6); grid.add(cbEnd, 1, 6);

            if (initial != null) {
                cbCourse.setValue(initial.courseCode);
                cbSection.setValue(initial.sectionName);
                cbTeacher.setValue(initial.teacherName);
                cbRoom.setValue(initial.roomCode);
                cbDay.setValue(initial.day);
                cbStart.setValue(initial.startTime);
                cbEnd.setValue(initial.endTime);
            }

            getDialogPane().setContent(grid);
            getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

            setResultConverter(dialogBtn -> {
                if (dialogBtn == ButtonType.OK) {
                    return new TimetableEntryData(
                            cbCourse.getValue(),
                            cbSection.getValue(),
                            cbTeacher.getValue(),
                            cbRoom.getValue(),
                            cbDay.getValue(),
                            cbStart.getValue(),
                            cbEnd.getValue()
                    );
                }
                return null;
            });
        }
    }

    private static class TimetableEntryData {
        String courseCode, sectionName, teacherName, roomCode, day, startTime, endTime;
        TimetableEntryData(String c, String s, String t, String r, String d, String st, String et) {
            courseCode = c; sectionName = s; teacherName = t;
            roomCode = r; day = d; startTime = st; endTime = et;
        }
        boolean isValid() {
            return courseCode != null && sectionName != null && teacherName != null
                    && roomCode != null && day != null && startTime != null && endTime != null;
        }
    }

    private void showAlert(String msg, Alert.AlertType type) {
        Alert alert = new Alert(type, msg, ButtonType.OK);
        alert.showAndWait();
    }

    @FXML
    private void handleGenerateTimetable(ActionEvent event) throws SQLException {
        // 1. Clear previous timetable from database
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("DELETE FROM Timetable");
        } catch (SQLException e) {
            showAlert("Error clearing timetable: " + e.getMessage(), Alert.AlertType.ERROR);
            return;
        }

        // 2. Prepare all lists/maps (reset for new generation)
        class RoomSlot {
            int roomID, floorNum, roomNum;
            String roomType;
            RoomSlot(int id, int f, int rn, String rt) {
                roomID = id; floorNum = f; roomNum = rn; roomType = rt;
            }
        }
        java.util.List<RoomSlot> normalRooms = new java.util.ArrayList<>();
        java.util.List<RoomSlot> labRooms = new java.util.ArrayList<>();
        java.util.Map<String, Boolean> roomBooked = new java.util.HashMap<>();
        java.util.Map<String, Boolean> teacherBooked = new java.util.HashMap<>();
        java.util.Map<String, Boolean> sectionBooked = new java.util.HashMap<>();
        java.util.Map<String, Integer[]> sessionDayCounts = new java.util.HashMap<>();

        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        String[] periods = {"08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"};

        // 3. Load rooms from database
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT r.RoomID, f.FloorNumber, r.RoomNumber, r.RoomType FROM Room r JOIN Floor f ON r.FloorID=f.FloorID");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                RoomSlot slot = new RoomSlot(
                        rs.getInt("RoomID"),
                        rs.getInt("FloorNumber"),
                        rs.getInt("RoomNumber"),
                        rs.getString("RoomType")
                );
                if ("Lab".equalsIgnoreCase(slot.roomType)) labRooms.add(slot);
                else normalRooms.add(slot);
            }
        } catch (SQLException e) {
            showAlert("Error loading rooms: " + e.getMessage(), Alert.AlertType.ERROR);
            return;
        }

        // 4. Load assignments from database
        class Assignment {
            int courseID, sectionID, creditHours;
            String courseCode, courseName, courseType, sectionName, teacherID, teacherName;
        }
        java.util.List<Assignment> assignments = new java.util.ArrayList<>();
        String sql =
                "SELECT c.CourseID, c.CourseCode, c.CourseName, c.CreditHours, c.CourseType, " +
                        "s.SectionID, s.SectionName, tc.TeacherID, t.Name AS TeacherName " +
                        "FROM CourseSection cs " +
                        "JOIN Course c ON cs.CourseID = c.CourseID " +
                        "JOIN Section s ON cs.SectionID = s.SectionID " +
                        "JOIN TeacherCourse tc ON c.CourseID = tc.CourseID " +
                        "JOIN Teacher t ON tc.TeacherID = t.TeacherID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Assignment a = new Assignment();
                a.courseID = rs.getInt("CourseID");
                a.courseCode = rs.getString("CourseCode");
                a.courseName = rs.getString("CourseName");
                a.creditHours = rs.getInt("CreditHours");
                a.courseType = rs.getString("CourseType");
                a.sectionID = rs.getInt("SectionID");
                a.sectionName = rs.getString("SectionName");
                a.teacherID = rs.getString("TeacherID");
                a.teacherName = rs.getString("TeacherName");
                assignments.add(a);
            }
        } catch (SQLException e) {
            showAlert("Error loading assignments: " + e.getMessage(), Alert.AlertType.ERROR);
            return;
        }

        // 5. Greedy slot allocation (reset all maps/lists first!)
        int scheduledCount = 0;

        for (Assignment a : assignments) {
            int sessions = "Lab".equalsIgnoreCase(a.courseType) ? 1 : a.creditHours;
            int slotLength = "Lab".equalsIgnoreCase(a.courseType) ? 3 : 1;
            String mapKey = a.sectionID + "-" + a.courseID;
            Integer[] counts = sessionDayCounts.computeIfAbsent(mapKey, k -> new Integer[days.length]);
            for (int i = 0; i < days.length; i++) if (counts[i] == null) counts[i] = 0;

            for (int s = 0; s < sessions; s++) {
                boolean found = false;
                // Find candidate day(s) with minimum sessions for this section-course
                int minCount = Integer.MAX_VALUE;
                java.util.List<Integer> candidateDays = new java.util.ArrayList<>();
                for (int i = 0; i < days.length; i++) {
                    if (counts[i] < minCount) {
                        minCount = counts[i];
                        candidateDays.clear();
                        candidateDays.add(i);
                    } else if (counts[i] == minCount) {
                        candidateDays.add(i);
                    }
                }
                int chosenDayIdx = candidateDays.get(0);

                // Try chosen day first, then others if needed
                int[] tryOrder = new int[days.length];
                tryOrder[0] = chosenDayIdx;
                int idx = 1;
                for (int i = 0; i < days.length; i++) {
                    if (i != chosenDayIdx) tryOrder[idx++] = i;
                }

                OUTER: for (int di = 0; di < days.length; di++) {
                    int d = tryOrder[di];
                    String day = days[d];
                    for (int p = 0; p < periods.length - slotLength; p++) { // ** FIXED BOUNDS **
                        System.out.println("periods.length: " + periods.length + ", slotLength: " + slotLength + ", p: " + p);
                        String start = periods[p];
                        String end = periods[p + slotLength];

                        java.util.List<RoomSlot> rooms = "Lab".equalsIgnoreCase(a.courseType) ? labRooms : normalRooms;
                        for (RoomSlot room : rooms) {
                            boolean clash = false;
                            for (int sp = 0; sp < slotLength; sp++) {
                                String tKey = day + "-" + periods[p + sp] + "-" + a.teacherID;
                                String sKey = day + "-" + periods[p + sp] + "-" + a.sectionID;
                                String rKey = day + "-" + periods[p + sp] + "-" + room.roomID;
                                if (roomBooked.getOrDefault(rKey, false)
                                        || teacherBooked.getOrDefault(tKey, false)
                                        || sectionBooked.getOrDefault(sKey, false)) {
                                    clash = true;
                                    break;
                                }
                            }
                            if (clash) continue;

                            // Book all slots for this block
                            for (int sp = 0; sp < slotLength; sp++) {
                                String tKey = day + "-" + periods[p + sp] + "-" + a.teacherID;
                                String sKey = day + "-" + periods[p + sp] + "-" + a.sectionID;
                                String rKey = day + "-" + periods[p + sp] + "-" + room.roomID;
                                teacherBooked.put(tKey, true);
                                sectionBooked.put(sKey, true);
                                roomBooked.put(rKey, true);
                            }
                            // Insert into timetable
                            try (Connection conn2 = DBConnection.getConnection();
                                 PreparedStatement ins = conn2.prepareStatement(
                                         "INSERT INTO Timetable (CourseID, TeacherID, SectionID, RoomID, DayOfWeek, StartTime, EndTime, IsLab) VALUES (?,?,?,?,?,?,?,?)")) {
                                ins.setInt(1, a.courseID);
                                ins.setString(2, a.teacherID);
                                ins.setInt(3, a.sectionID);
                                ins.setInt(4, room.roomID);
                                ins.setString(5, day);
                                ins.setString(6, start);
                                ins.setString(7, end);
                                ins.setBoolean(8, "Lab".equalsIgnoreCase(a.courseType));
                                ins.executeUpdate();
                            }
                            scheduledCount++;
                            counts[d]++;
                            found = true;
                            break OUTER;
                        }
                    }
                }
                if (!found) {
                    showAlert("Could not schedule all sessions for: " + a.courseCode + " (" + a.sectionName + ")", Alert.AlertType.ERROR);
                    break;
                }
            }
        }

        // 6. Refresh your TableView/UI
        loadTimetable();

        // 7. Success message
        showAlert("Auto-generated timetable for " + scheduledCount + " sessions.", Alert.AlertType.INFORMATION);
    }

    @FXML
    private void handleDownloadPDF(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Timetable PDF");
        fileChooser.setInitialFileName("Timetable.pdf");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        Stage stage = (Stage) tableTimetable.getScene().getWindow();
        java.io.File file = fileChooser.showSaveDialog(stage);
        if (file == null) return;

        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter.getInstance(document, new java.io.FileOutputStream(file));
            document.open();

            Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
            Paragraph title = new Paragraph("Generated Timetable", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph(" "));

            PdfPTable pdfTable = new PdfPTable(10);
            pdfTable.setWidthPercentage(100);
            String[] headers = {"Day", "Start", "End", "Course Code", "Course Name", "Section", "Teacher", "Room", "Floor", "Room Type"};
            for (String header : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(header, new Font(Font.HELVETICA, 12, Font.BOLD)));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                pdfTable.addCell(cell);
            }

            for (TimetableDisplayRow row : tableTimetable.getItems()) {
                pdfTable.addCell(row.getDay());
                pdfTable.addCell(row.getStartTime());
                pdfTable.addCell(row.getEndTime());
                pdfTable.addCell(row.getCourseCode());
                pdfTable.addCell(row.getCourseName());
                pdfTable.addCell(row.getSection());
                pdfTable.addCell(row.getTeacher());
                pdfTable.addCell(row.getRoom());
                pdfTable.addCell(row.getFloor());
                pdfTable.addCell(row.getRoomType());
            }

            document.add(pdfTable);
            document.close();

            showAlert("PDF saved successfully!", Alert.AlertType.INFORMATION);

        } catch (Exception e) {
            showAlert("Failed to save PDF: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            showAlert("Navigation failed: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
}
