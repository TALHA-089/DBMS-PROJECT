package com.example.studentmanagementsystem.Models;

public class CourseViewRow {
    private int courseId;
    private String courseCode;
    private String courseName;
    private String departmentName;
    private String semesterName; // NEW

    // Updated constructor (now takes semesterName)
    public CourseViewRow(int courseId, String courseCode, String courseName, String departmentName, String semesterName) {
        this.courseId = courseId;
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.departmentName = departmentName;
        this.semesterName = semesterName;
    }

    // Getters
    public int getCourseId() { return courseId; }
    public String getCourseCode() { return courseCode; }
    public String getCourseName() { return courseName; }
    public String getDepartmentName() { return departmentName; }
    public String getSemesterName() { return semesterName; } // NEW
}
