package com.example.studentmanagementsystem.DashBoards.Student.NotesManager;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.Models.NoteRow;
import com.example.studentmanagementsystem.Models.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.sql.*;

public class NotesManagerController {
    @FXML private TableView<NoteRow> tableNotes;
    @FXML private TableColumn<NoteRow, String> colFileName, colFileType, colUploadDate;
    @FXML private Button btnUpload, btnDownload, btnDelete, btnGoBack;
    @FXML private Label lblStatus;

    private Student cStudent;

    public void setStudent(Student s) {
        cStudent = s;
        loadNotes();
    }

    private ObservableList<NoteRow> notes = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colFileName.setCellValueFactory(data -> data.getValue().fileNameProperty());
        colFileType.setCellValueFactory(data -> data.getValue().fileTypeProperty());
        colUploadDate.setCellValueFactory(data -> data.getValue().uploadDateProperty());
    }

    private void loadNotes() {
        notes.clear();
        if (cStudent == null) return;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT NoteID, FileName, FileType, UploadDate FROM StudentNotes WHERE Enrollment = ?"
             )) {
            stmt.setString(1, cStudent.getEnrollment());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                notes.add(new NoteRow(
                        rs.getInt("NoteID"),
                        rs.getString("FileName"),
                        rs.getString("FileType"),
                        rs.getTimestamp("UploadDate")
                ));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Failed", "Load failed: " + e.getMessage());
        }
        tableNotes.setItems(notes);
    }

    @FXML
    private void handleUploadNote() {
        if (cStudent == null) {
            showAlert(Alert.AlertType.ERROR, "Student Error", "Student info not found.");
            return;
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Note File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Documents", "*.pdf", "*.docx")
        );
        File file = fileChooser.showOpenDialog(btnUpload.getScene().getWindow());
        if (file == null) return;
        try {
            byte[] fileBytes = Files.readAllBytes(file.toPath());
            String fileName = file.getName();
            String fileType = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();

            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                         "INSERT INTO StudentNotes (Enrollment, FileName, FileType, FileData) VALUES (?, ?, ?, ?)"
                 )) {
                stmt.setString(1, cStudent.getEnrollment());
                stmt.setString(2, fileName);
                stmt.setString(3, fileType);
                stmt.setBytes(4, fileBytes);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Upload successful.");
                loadNotes();
            }
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "File Read Error", "File read failed: " + e.getMessage());
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Upload Failed", "Upload failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleDownloadNote() {
        NoteRow selected = tableNotes.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Select a note to download.");
            return;
        }
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT FileName, FileData FROM StudentNotes WHERE NoteID=?"
             )) {
            stmt.setInt(1, selected.getNoteId());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String fileName = rs.getString("FileName");
                byte[] fileBytes = rs.getBytes("FileData");
                FileChooser fileChooser = new FileChooser();
                fileChooser.setInitialFileName(fileName);
                File saveFile = fileChooser.showSaveDialog(btnDownload.getScene().getWindow());
                if (saveFile != null) {
                    Files.write(saveFile.toPath(), fileBytes);
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Download successful.");
                }
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Download Failed", "Download failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteNote() {
        NoteRow selected = tableNotes.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Select a note to delete.");
            return;
        }
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "DELETE FROM StudentNotes WHERE NoteID=?"
             )) {
            stmt.setInt(1, selected.getNoteId());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Deleted", "Note deleted.");
                loadNotes();
            } else {
                showAlert(Alert.AlertType.WARNING, "Delete Failed", "Delete failed.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Delete Failed", "Delete failed: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public void handleGoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 400);
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            // Pass student back to dashboard
            com.example.studentmanagementsystem.DashBoards.Student.StudentDashBoard controller = loader.getController();
            controller.setStudentProfile(cStudent);
            stage.setScene(scene);
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not go back: " + e.getMessage());
        }
    }
}
