package com.example.studentmanagementsystem.Models;

public class StudentCourse {
    private String enrollment;
    private int courseId;

    public StudentCourse(String enrollment, int courseId) {
        this.enrollment = enrollment;
        this.courseId = courseId;
    }

    public String getEnrollment() { return enrollment; }
    public void setEnrollment(String enrollment) { this.enrollment = enrollment; }

    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
}
