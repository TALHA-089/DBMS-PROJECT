package com.example.studentmanagementsystem.DashBoards.Student;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DashBoards.Student.CourseRegistration.CourseRegistrationController;
import com.example.studentmanagementsystem.DashBoards.Student.GPACalculator.GPACalculatorController;
import com.example.studentmanagementsystem.DashBoards.Student.NotesManager.NotesManagerController;
import com.example.studentmanagementsystem.DashBoards.Student.Transcript.TranscriptController;
import com.example.studentmanagementsystem.DashBoards.Student.ViewProfile.ViewProfileController;
import com.example.studentmanagementsystem.DashBoards.Student.ViewTimeTable.ViewTimeTableController;
import com.example.studentmanagementsystem.Models.Student;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;

public class StudentDashBoard {

    private Student currentStudent;

    // Example FXML buttons (add fx:id to FXML and link their onAction)
    @FXML private Button btnCourseRegistration;
    @FXML private Button btnGpaCalculator;
    @FXML private Button btnTranscript;
    @FXML private Button btnViewTimetable;
    @FXML private Button btnNotesManager;
    @FXML private Button btnViewProfile;
    @FXML private Button btnSignout;

    // Call this after login to pass logged-in student info
    public void setStudentProfile(Student student) {
        this.currentStudent = student;
    }

    @FXML
    private void goToCourseRegistration() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/CourseRegistration/CourseRegistration.fxml"));
            Scene scene = new Scene(loader.load());
            CourseRegistrationController controller = loader.getController();
            controller.setStudent(currentStudent);
            Stage stage = (Stage) btnCourseRegistration.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Course Registration");
        } catch (Exception e) {
            showError("Could not open Course Registration", e);
        }
    }
    @FXML
    private void goToNotesManager() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/NotesManager/NotesManager.fxml"));
            Scene scene = new Scene(loader.load(),700,420);
            NotesManagerController controller = loader.getController();
            controller.setStudent(currentStudent);
            Stage stage = (Stage) btnNotesManager.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Notes Manager");
        } catch (Exception e) {
            showError("Could not open Course Registration", e);
        }
    }
    @FXML
    private void goToViewProfile() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/ViewProfile/ViewProfile.fxml"));
            Scene scene = new Scene(loader.load(),440,440);
            ViewProfileController controller = loader.getController();
            controller.setStudent(currentStudent);
            Stage stage = (Stage) btnViewProfile.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Student Profile");
        } catch (Exception e) {
            showError("Could not open Course Registration", e);
        }
    }

    @FXML
    private void goToGpaCalculator() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/gpaCalculator/GpaCalculator.fxml"));
            Scene scene = new Scene(loader.load(),600,500);
            GPACalculatorController controller = loader.getController();
            controller.setStudent(currentStudent);
            Stage stage = (Stage) btnGpaCalculator.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("GPA Calculator");
        } catch (Exception e) {
            showError("Could not open GPA Calculator", e);
        }
    }

    @FXML
    private void goToTranscript() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/Transcript/Transcript.fxml"));
            Scene scene = new Scene(loader.load(),850,600);
            TranscriptController controller = loader.getController();
            controller.setStudent(currentStudent);
            Stage stage = (Stage) btnTranscript.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Transcript");
        } catch (Exception e) {
            showError("Could not open Transcript", e);
        }
    }

    @FXML
    private void goToViewTimetable() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXMLS/ViewTimeTable/ViewTimetable.fxml"));
            Scene scene = new Scene(loader.load());
            ViewTimeTableController controller = loader.getController();
            controller.setStudent(currentStudent);
            Stage stage = (Stage) btnViewTimetable.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("My Timetable");
        } catch (Exception e) {
            showError("Could not open Timetable", e);
        }
    }

    @FXML public void Signout() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Sign Out");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to sign out?");
        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            try {
                Stage stage = (Stage) Stage.getWindows().filtered(Window::isShowing).getFirst();
                FXMLLoader fxmlLoader = new FXMLLoader(CMS.class.getResource("/FXMLS/CMS.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 470);
                stage.setScene(scene);
                stage.setTitle("Login Page");
                stage.setResizable(false);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Error", "Unable to return to login screen.");
            }
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void showError(String message, Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message + "\n" + e.getMessage());
        alert.showAndWait();
        e.printStackTrace();
    }
}
