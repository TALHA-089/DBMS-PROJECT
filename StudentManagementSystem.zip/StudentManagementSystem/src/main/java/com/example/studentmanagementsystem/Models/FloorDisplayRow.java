package com.example.studentmanagementsystem.Models;

public class FloorDisplayRow {
    private int floorID;
    private int floorNumber;
    private String departmentName;

    public FloorDisplayRow(int floorID, int floorNumber, String departmentName) {
        this.floorID = floorID;
        this.floorNumber = floorNumber;
        this.departmentName = departmentName;
    }

    public int getFloorID() { return floorID; }
    public int getFloorNumber() { return floorNumber; }
    public String getDepartmentName() { return departmentName; }
}
