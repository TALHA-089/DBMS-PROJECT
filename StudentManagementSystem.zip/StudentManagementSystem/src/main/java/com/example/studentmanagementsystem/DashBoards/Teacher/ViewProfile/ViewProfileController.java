package com.example.studentmanagementsystem.DashBoards.Teacher.ViewProfile;

import com.example.studentmanagementsystem.DashBoards.Teacher.TeacherDashBoard;
import com.example.studentmanagementsystem.Models.Teacher;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import com.example.studentmanagementsystem.CMS;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ViewProfileController {
    @FXML private TextField tfTeacherID, tfName, tfEmail, tfPhone;
    @FXML private PasswordField tfPassword;
    @FXML private Button btnUpdate, btnGoBack;

    private Teacher currentTeacher;

    public void setTeacher(Teacher t) {
        this.currentTeacher = t;
        tfTeacherID.setText(t.getTeacherID());
        tfName.setText(t.getName());
        tfEmail.setText(t.getEmail());
        tfPhone.setText(t.getPhone());
        tfPassword.setText(t.getPassword());
    }

    @FXML
    private void handleUpdateProfile() {
        String name = tfName.getText().trim();
        String email = tfEmail.getText().trim();
        String phone = tfPhone.getText().trim();
        String password = tfPassword.getText().trim();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            showAlert("Please fill all fields.", Alert.AlertType.ERROR);
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE Teacher SET Name=?, Email=?, Phone=?, Password=? WHERE TeacherID=?"
             )) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phone);
            stmt.setString(4, password);
            stmt.setString(5, tfTeacherID.getText());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showAlert("Profile updated successfully!", Alert.AlertType.INFORMATION);
                // Also update the Teacher model in memory:
                currentTeacher.setName(name);
                currentTeacher.setEmail(email);
                currentTeacher.setPhone(phone);
                currentTeacher.setPassword(password);
            } else {
                showAlert("Update failed. Try again.", Alert.AlertType.ERROR);
            }
        } catch (Exception e) {
            showAlert("Update failed: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleGoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 600, 400));
            // Optionally pass back the teacher model if needed:
            TeacherDashBoard controller = loader.getController();
            controller.setTeacher(currentTeacher);
        } catch (Exception e) {
            showAlert("Navigation failed: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String msg, Alert.AlertType type) {
        Alert alert = new Alert(type, msg, ButtonType.OK);
        alert.showAndWait();
    }
}
