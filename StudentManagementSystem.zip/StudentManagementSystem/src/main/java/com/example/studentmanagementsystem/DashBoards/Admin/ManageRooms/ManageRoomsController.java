package com.example.studentmanagementsystem.DashBoards.Admin.ManageRooms;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.RoomDisplayRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.sql.*;

public class ManageRoomsController {

    @FXML private TableView<RoomDisplayRow> tableRooms;
    @FXML private TableColumn<RoomDisplayRow, Integer> colRoomID, colRoomNumber, colFloorNumber;
    @FXML private TableColumn<RoomDisplayRow, String> colRoomCode, colRoomType;
    @FXML private TextField tfRoomNumber;
    @FXML private ComboBox<String> cbFloor, cbRoomType;
    @FXML private ImageView GoBack;
    

    private int selectedRoomID = -1;
    private int selectedFloorNumber = -1;

    @FXML
    public void initialize() {
        colRoomID.setCellValueFactory(new PropertyValueFactory<>("roomID"));
        colRoomCode.setCellValueFactory(new PropertyValueFactory<>("roomCode"));
        colRoomNumber.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        colFloorNumber.setCellValueFactory(new PropertyValueFactory<>("floorNumber"));
        colRoomType.setCellValueFactory(new PropertyValueFactory<>("roomType"));

        loadFloors();
        loadRoomTypes();
        loadRooms();

        tableRooms.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                tfRoomNumber.setText(String.valueOf(newSel.getRoomNumber()));
                cbFloor.setValue(String.valueOf(newSel.getFloorNumber()));
                cbRoomType.setValue(newSel.getRoomType());
                selectedRoomID = newSel.getRoomID();
            }
        });
    }

    private void loadFloors() {
        ObservableList<String> floors = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT FloorNumber FROM Floor ORDER BY FloorNumber")) {
            while (rs.next()) floors.add(String.valueOf(rs.getInt("FloorNumber")));
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Unable to load floors:\n" + e.getMessage());
        }
        cbFloor.setItems(floors);
    }

    private void loadRoomTypes() {
        ObservableList<String> types = FXCollections.observableArrayList("Normal", "Lab");
        cbRoomType.setItems(types);
    }

    private void loadRooms() {
        ObservableList<RoomDisplayRow> rows = FXCollections.observableArrayList();
        String query = "SELECT r.RoomID, r.RoomNumber, r.RoomType, f.FloorNumber " +
                "FROM Room r JOIN Floor f ON r.FloorID = f.FloorID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int roomID = rs.getInt("RoomID");
                int roomNumber = rs.getInt("RoomNumber");
                String roomType = rs.getString("RoomType");
                int floorNumber = rs.getInt("FloorNumber");
                String roomCode = floorNumber + "-" + roomNumber;
                rows.add(new RoomDisplayRow(roomID, roomCode, roomNumber, floorNumber, roomType));
            }
            tableRooms.setItems(rows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Could not load rooms: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddRoom(ActionEvent event) {
        String roomNumText = tfRoomNumber.getText().trim();
        String floorNumText = cbFloor.getValue();
        String roomType = cbRoomType.getValue();
        if (roomNumText.isEmpty() || floorNumText == null || roomType == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all fields.");
            return;
        }
        int roomNumber = Integer.parseInt(roomNumText);
        int floorNumber = Integer.parseInt(floorNumText);
        int floorId = getFloorIdByNumber(floorNumber);
        if (floorId == -1) {
            showAlert(Alert.AlertType.ERROR, "Floor Error", "Invalid floor.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String insert = "INSERT INTO Room (RoomNumber, FloorID, RoomType) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                stmt.setInt(1, roomNumber);
                stmt.setInt(2, floorId);
                stmt.setString(3, roomType);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Room added.");
                loadRooms();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Add Error", "Could not add room: " + e.getMessage());
        }
    }

    @FXML
    private void handleUpdateRoom(ActionEvent event) {
        if (selectedRoomID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No room selected.");
            return;
        }
        String roomNumText = tfRoomNumber.getText().trim();
        String floorNumText = cbFloor.getValue();
        String roomType = cbRoomType.getValue();
        if (roomNumText.isEmpty() || floorNumText == null || roomType == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all fields.");
            return;
        }
        int roomNumber = Integer.parseInt(roomNumText);
        int floorNumber = Integer.parseInt(floorNumText);
        int floorId = getFloorIdByNumber(floorNumber);
        if (floorId == -1) {
            showAlert(Alert.AlertType.ERROR, "Floor Error", "Invalid floor.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String update = "UPDATE Room SET RoomNumber=?, FloorID=?, RoomType=? WHERE RoomID=?";
            try (PreparedStatement stmt = conn.prepareStatement(update)) {
                stmt.setInt(1, roomNumber);
                stmt.setInt(2, floorId);
                stmt.setString(3, roomType);
                stmt.setInt(4, selectedRoomID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Room updated.");
                loadRooms();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Update Error", "Could not update room: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteRoom(ActionEvent event) {
        if (selectedRoomID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No room selected.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String delete = "DELETE FROM Room WHERE RoomID=?";
            try (PreparedStatement stmt = conn.prepareStatement(delete)) {
                stmt.setInt(1, selectedRoomID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Room deleted.");
                loadRooms();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Delete Error", "Could not delete room: " + e.getMessage());
        }
    }

    @FXML
    private void handleClearFields(ActionEvent event) {
        tfRoomNumber.clear();
        cbFloor.getSelectionModel().clearSelection();
        cbRoomType.getSelectionModel().clearSelection();
        tableRooms.getSelectionModel().clearSelection();
        selectedRoomID = -1;
    }

    private int getFloorIdByNumber(int floorNumber) {
        String query = "SELECT FloorID FROM Floor WHERE FloorNumber=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, floorNumber);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("FloorID");
        } catch (SQLException e) {}
        return -1;
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow(); // or use any node from your scene
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
