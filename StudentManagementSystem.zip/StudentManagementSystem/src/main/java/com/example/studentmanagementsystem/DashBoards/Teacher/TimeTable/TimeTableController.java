package com.example.studentmanagementsystem.DashBoards.Teacher.TimeTable;

import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.DashBoards.Teacher.TeacherDashBoard;
import com.example.studentmanagementsystem.Models.Teacher;
import com.example.studentmanagementsystem.Models.TimetableDisplayRow;
import com.example.studentmanagementsystem.CMS;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TimeTableController {
    private Teacher currentTeacher;

    @FXML private TableView<TimetableDisplayRow> tableTimeTable;
    @FXML private TableColumn<TimetableDisplayRow, String> colDay, colStartTime, colEndTime, colCourseCode, colCourseName, colSection, colRoom, colRoomType;
    @FXML private Button btnGoBack;

    public void setTeacher(Teacher T) {
        this.currentTeacher = T;
        loadTeacherTimeTable();
    }

    @FXML
    public void initialize() {
        colDay.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDay()));
        colStartTime.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getStartTime()));
        colEndTime.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getEndTime()));
        colCourseCode.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getCourseCode()));
        colCourseName.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getCourseName()));
        colSection.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getSection()));
        colRoom.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getRoom()));
        colRoomType.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getRoomType()));
        // Data loaded in setTeacher()
    }

    private void loadTeacherTimeTable() {
        ObservableList<TimetableDisplayRow> timetableRows = FXCollections.observableArrayList();
        if (currentTeacher == null) return;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT t.TimetableID, t.DayOfWeek, t.StartTime, t.EndTime, c.CourseCode, c.CourseName, " +
                             "s.SectionName, te.Name as TeacherName, r.RoomNumber, r.RoomType " +
                             "FROM Timetable t " +
                             "JOIN Course c ON t.CourseID = c.CourseID " +
                             "JOIN Section s ON t.SectionID = s.SectionID " +
                             "JOIN Teacher te ON t.TeacherID = te.TeacherID " +
                             "JOIN Room r ON t.RoomID = r.RoomID " +
                             "WHERE t.TeacherID = ? " +
                             "ORDER BY t.DayOfWeek, t.StartTime"
             )) {
            stmt.setString(1, currentTeacher.getTeacherID());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                timetableRows.add(new TimetableDisplayRow(
                        rs.getInt("TimetableID"),
                        rs.getString("DayOfWeek"),
                        rs.getString("StartTime"),
                        rs.getString("EndTime"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getString("SectionName"),
                        rs.getString("TeacherName"),
                        rs.getString("RoomNumber"),
                        "", // floor not shown here, can be added if needed
                        rs.getString("RoomType")
                ));
            }
            tableTimeTable.setItems(timetableRows);
        } catch (Exception e) {
            showAlert("Failed to load timetable: " + e.getMessage());
        }
    }

    @FXML
    private void goBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
            Stage stage = (Stage) btnGoBack.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 600, 420));
            TeacherDashBoard controller = loader.getController();
            controller.setTeacher(currentTeacher);
        } catch (Exception e) {
            showAlert("Navigation failed: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.showAndWait();
    }
}
