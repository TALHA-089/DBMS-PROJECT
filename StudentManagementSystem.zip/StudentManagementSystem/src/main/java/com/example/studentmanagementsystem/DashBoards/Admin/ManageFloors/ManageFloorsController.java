package com.example.studentmanagementsystem.DashBoards.Admin.ManageFloors;


import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.Models.FloorDisplayRow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.sql.*;

public class ManageFloorsController {

    @FXML private TableView<FloorDisplayRow> tableFloors;
    @FXML private TableColumn<FloorDisplayRow, Integer> colFloorID, colFloorNumber;
    @FXML private TableColumn<FloorDisplayRow, String> colDepartmentName;
    @FXML private TextField tfFloorNumber;
    @FXML private ComboBox<String> cbDepartment;
    @FXML private ImageView GoBack;
    private int selectedFloorID = -1;

    @FXML
    public void initialize() {
        colFloorID.setCellValueFactory(new PropertyValueFactory<>("floorID"));
        colFloorNumber.setCellValueFactory(new PropertyValueFactory<>("floorNumber"));
        colDepartmentName.setCellValueFactory(new PropertyValueFactory<>("departmentName"));

        loadDepartments();
        loadFloors();

        tableFloors.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                tfFloorNumber.setText(String.valueOf(newSel.getFloorNumber()));
                cbDepartment.setValue(newSel.getDepartmentName());
                selectedFloorID = newSel.getFloorID();
            }
        });
    }

    private void loadDepartments() {
        ObservableList<String> departments = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DepartmentName FROM Department")) {
            while (rs.next()) departments.add(rs.getString("DepartmentName"));
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Unable to load departments:\n" + e.getMessage());
        }
        cbDepartment.setItems(departments);
    }

    private void loadFloors() {
        ObservableList<FloorDisplayRow> rows = FXCollections.observableArrayList();
        String query = "SELECT f.FloorID, f.FloorNumber, d.DepartmentName " +
                "FROM Floor f JOIN Department d ON f.DepartmentID = d.DepartmentID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                rows.add(new FloorDisplayRow(
                        rs.getInt("FloorID"),
                        rs.getInt("FloorNumber"),
                        rs.getString("DepartmentName")
                ));
            }
            tableFloors.setItems(rows);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Load Error", "Could not load floors: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddFloor(ActionEvent event) {
        String floorNumText = tfFloorNumber.getText().trim();
        String departmentName = cbDepartment.getValue();
        if (floorNumText.isEmpty() || departmentName == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all fields.");
            return;
        }
        int floorNumber = Integer.parseInt(floorNumText);
        int departmentId = getDepartmentIdByName(departmentName);
        if (departmentId == -1) {
            showAlert(Alert.AlertType.ERROR, "Department Error", "Invalid department.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String insert = "INSERT INTO Floor (FloorNumber, DepartmentID) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insert)) {
                stmt.setInt(1, floorNumber);
                stmt.setInt(2, departmentId);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Floor added.");
                loadFloors();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Add Error", "Could not add floor: " + e.getMessage());
        }
    }

    @FXML
    private void handleUpdateFloor(ActionEvent event) {
        if (selectedFloorID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No floor selected.");
            return;
        }
        String floorNumText = tfFloorNumber.getText().trim();
        String departmentName = cbDepartment.getValue();
        if (floorNumText.isEmpty() || departmentName == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Fill all fields.");
            return;
        }
        int floorNumber = Integer.parseInt(floorNumText);
        int departmentId = getDepartmentIdByName(departmentName);
        if (departmentId == -1) {
            showAlert(Alert.AlertType.ERROR, "Department Error", "Invalid department.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String update = "UPDATE Floor SET FloorNumber=?, DepartmentID=? WHERE FloorID=?";
            try (PreparedStatement stmt = conn.prepareStatement(update)) {
                stmt.setInt(1, floorNumber);
                stmt.setInt(2, departmentId);
                stmt.setInt(3, selectedFloorID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Floor updated.");
                loadFloors();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Update Error", "Could not update floor: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteFloor(ActionEvent event) {
        if (selectedFloorID == -1) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "No floor selected.");
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String delete = "DELETE FROM Floor WHERE FloorID=?";
            try (PreparedStatement stmt = conn.prepareStatement(delete)) {
                stmt.setInt(1, selectedFloorID);
                stmt.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Floor deleted.");
                loadFloors();
                handleClearFields(null);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Delete Error", "Could not delete floor: " + e.getMessage());
        }
    }

    @FXML
    private void handleClearFields(ActionEvent event) {
        tfFloorNumber.clear();
        cbDepartment.getSelectionModel().clearSelection();
        tableFloors.getSelectionModel().clearSelection();
        selectedFloorID = -1;
    }

    private int getDepartmentIdByName(String departmentName) {
        String query = "SELECT DepartmentID FROM Department WHERE DepartmentName=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, departmentName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("DepartmentID");
        } catch (SQLException e) {}
        return -1;
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void GoBack() {
        try {
            FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(loader.load(), 600, 608);
            Stage stage = (Stage) GoBack.getScene().getWindow(); // or use any node from your scene
            stage.setScene(scene);
            stage.setTitle("Admin Dashboard");
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
