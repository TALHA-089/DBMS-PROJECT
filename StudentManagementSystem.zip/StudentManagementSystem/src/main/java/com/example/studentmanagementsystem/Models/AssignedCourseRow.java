package com.example.studentmanagementsystem.Models;

public class AssignedCourseRow {
    private int courseId;
    private String courseCode;
    private String courseName;

    public AssignedCourseRow(int courseId, String courseCode, String courseName) {
        this.courseId = courseId;
        this.courseCode = courseCode;
        this.courseName = courseName;
    }

    public int getCourseId() { return courseId; }
    public String getCourseCode() { return courseCode; }
    public String getCourseName() { return courseName; }
}
