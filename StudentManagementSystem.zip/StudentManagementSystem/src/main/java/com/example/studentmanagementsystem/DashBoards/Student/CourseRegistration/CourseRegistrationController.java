package com.example.studentmanagementsystem.DashBoards.Student.CourseRegistration;

import com.example.studentmanagementsystem.CMS;
import com.example.studentmanagementsystem.DBconnection.DBConnection;
import com.example.studentmanagementsystem.DashBoards.Student.StudentDashBoard;
import com.example.studentmanagementsystem.Models.CourseRow;
import com.example.studentmanagementsystem.Models.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class CourseRegistrationController {

    @FXML private TableView<CourseRow> tableAvailableCourses;
    @FXML private TableColumn<CourseRow, String> colCode, colName, colType;
    @FXML private TableColumn<CourseRow, Integer> colCredits;
    @FXML private TableView<CourseRow> tableRegisteredCourses;
    @FXML private TableColumn<CourseRow, String> colRegCode, colRegName, colRegType;
    @FXML private TableColumn<CourseRow, Integer> colRegCredits;
    @FXML private Button btnRegister, btnDrop, GoBack;
    @FXML private Label lblStatus;

    // Set this value after login
    Student cStudent;
    public void setStudent(Student s){
        cStudent = s;
        setEnrollment();
        loadCourses();
    }
    private String enrollment = "";

    public void setEnrollment(){
        this.enrollment = cStudent.getEnrollment();
    }

    @FXML
    public void initialize() {
        // Set up columns for Available Courses
        colCode.setCellValueFactory(data -> data.getValue().courseCodeProperty());
        colName.setCellValueFactory(data -> data.getValue().courseNameProperty());
        colType.setCellValueFactory(data -> data.getValue().courseTypeProperty());
        colCredits.setCellValueFactory(data -> data.getValue().creditHoursProperty().asObject());

        // Set up columns for Registered Courses
        colRegCode.setCellValueFactory(data -> data.getValue().courseCodeProperty());
        colRegName.setCellValueFactory(data -> data.getValue().courseNameProperty());
        colRegType.setCellValueFactory(data -> data.getValue().courseTypeProperty());
        colRegCredits.setCellValueFactory(data -> data.getValue().creditHoursProperty().asObject());

    }

    private void loadCourses() {
        ObservableList<CourseRow> available = FXCollections.observableArrayList();
        ObservableList<CourseRow> registered = FXCollections.observableArrayList();

        // Get current active semester
        int activeSemesterId = -1;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT SemesterID FROM Semester WHERE Status='Active' LIMIT 1");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) activeSemesterId = rs.getInt("SemesterID");
        } catch (Exception e) { showStatus("DB Error: " + e.getMessage()); }

        if (activeSemesterId == -1) {
            showStatus("No active semester!");
            return;
        }

        // Load registered courses
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT c.CourseID, c.CourseCode, c.CourseName, c.CreditHours, c.CourseType, sg.Status " +
                             "FROM StudentGrade sg " +
                             "JOIN Course c ON sg.CourseID = c.CourseID " +
                             "WHERE sg.Enrollment=? AND sg.SemesterID=?"
             )) {
            stmt.setString(1, enrollment);
            stmt.setInt(2, activeSemesterId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                registered.add(new CourseRow(
                        rs.getInt("CourseID"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getInt("CreditHours"),
                        rs.getString("CourseType"),
                        rs.getString("Status")
                ));
            }
        } catch (SQLException e) {
            showStatus("Failed to load registered: " + e.getMessage());
        }

        // Load available courses (not already registered)
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT c.CourseID, c.CourseCode, c.CourseName, c.CreditHours, c.CourseType " +
                             "FROM Course c " +
                             "WHERE c.SemesterID = ? " +
                             "AND c.CourseID NOT IN (SELECT CourseID FROM StudentGrade WHERE Enrollment=? AND SemesterID=?)"
             )) {
            stmt.setInt(1, activeSemesterId);
            stmt.setString(2, enrollment);
            stmt.setInt(3, activeSemesterId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                available.add(new CourseRow(
                        rs.getInt("CourseID"),
                        rs.getString("CourseCode"),
                        rs.getString("CourseName"),
                        rs.getInt("CreditHours"),
                        rs.getString("CourseType"),
                        "Not Registered"
                ));
            }
        } catch (SQLException e) {
            showStatus("Failed to load available: " + e.getMessage());
        }

        tableAvailableCourses.setItems(available);
        tableRegisteredCourses.setItems(registered);
        lblStatus.setText(""); // clear on refresh
    }

    @FXML
    private void handleRegisterCourse() {
        CourseRow selected = tableAvailableCourses.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showStatus("Select a course to register.");
            return;
        }

        // Get active semester
        int semesterId = getActiveSemesterId();
        if (semesterId == -1) { showStatus("No active semester."); return; }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO StudentGrade (Enrollment, CourseID, SemesterID, Status) VALUES (?,?,?,?)"
             )) {
            stmt.setString(1, enrollment);
            stmt.setInt(2, selected.getCourseId());
            stmt.setInt(3, semesterId);
            stmt.setString(4, "In Progress");
            stmt.executeUpdate();
            showStatus("Course registered!");
            loadCourses();
        } catch (SQLException e) {
            if (e.getMessage().contains("duplicate")) {
                showStatus("Already registered!");
            } else {
                showStatus("Register failed: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleDropCourse() {
        CourseRow selected = tableRegisteredCourses.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showStatus("Select a course to drop.");
            return;
        }
        if (!"In Progress".equalsIgnoreCase(selected.getStatus())) {
            showStatus("Cannot drop: grading in progress or completed.");
            return;
        }
        int semesterId = getActiveSemesterId();
        if (semesterId == -1) { showStatus("No active semester."); return; }
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "DELETE FROM StudentGrade WHERE Enrollment=? AND CourseID=? AND SemesterID=? AND Status='In Progress'"
             )) {
            stmt.setString(1, enrollment);
            stmt.setInt(2, selected.getCourseId());
            stmt.setInt(3, semesterId);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showStatus("Course dropped.");
            } else {
                showStatus("Unable to drop course.");
            }
            loadCourses();
        } catch (SQLException e) {
            showStatus("Drop failed: " + e.getMessage());
        }
    }

    private int getActiveSemesterId() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT SemesterID FROM Semester WHERE Status='Active' LIMIT 1");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("SemesterID");
        } catch (Exception e) { }
        return -1;
    }

    @FXML
    private void GoBack() throws IOException {
        FXMLLoader loader = new FXMLLoader(CMS.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
        Stage stage = (Stage) GoBack.getScene().getWindow();
        stage.setScene(new Scene(loader.load(), 600, 400));
        StudentDashBoard controller = loader.getController();
        controller.setStudentProfile(cStudent);
    }

    private void showStatus(String msg) {
        lblStatus.setText(msg);
    }
}
