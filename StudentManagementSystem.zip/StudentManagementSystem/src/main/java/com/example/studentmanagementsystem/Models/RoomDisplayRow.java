package com.example.studentmanagementsystem.Models;

public class RoomDisplayRow {
    private int roomID;
    private String roomCode; // e.g. "4-17"
    private int roomNumber;
    private int floorNumber;
    private String roomType;

    public RoomDisplayRow(int roomID, String roomCode, int roomNumber, int floorNumber, String roomType) {
        this.roomID = roomID;
        this.roomCode = roomCode;
        this.roomNumber = roomNumber;
        this.floorNumber = floorNumber;
        this.roomType = roomType;
    }

    public int getRoomID() { return roomID; }
    public String getRoomCode() { return roomCode; }
    public int getRoomNumber() { return roomNumber; }
    public int getFloorNumber() { return floorNumber; }
    public String getRoomType() { return roomType; }
}
