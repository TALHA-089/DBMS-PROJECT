package com.example.studentmanagementsystem.Models;

import javafx.beans.property.*;

public class TranscriptRow {
    private final StringProperty semesterName, courseCode, courseName, grade, status;
    private final IntegerProperty creditHours;
    private final DoubleProperty gpa;

    public TranscriptRow(String semester, String code, String name, int credits, String grade, double gpa, String status) {
        this.semesterName = new SimpleStringProperty(semester);
        this.courseCode = new SimpleStringProperty(code);
        this.courseName = new SimpleStringProperty(name);
        this.creditHours = new SimpleIntegerProperty(credits);
        this.grade = new SimpleStringProperty(grade);
        this.gpa = new SimpleDoubleProperty(gpa);
        this.status = new SimpleStringProperty(status);
    }
    public StringProperty semesterNameProperty() { return semesterName; }
    public StringProperty courseCodeProperty() { return courseCode; }
    public StringProperty courseNameProperty() { return courseName; }
    public IntegerProperty creditHoursProperty() { return creditHours; }
    public StringProperty gradeProperty() { return grade; }
    public DoubleProperty gpaProperty() { return gpa; }
    public StringProperty statusProperty() { return status; }

    public String getSemesterName() { return semesterName.get(); }
    public String getCourseCode() { return courseCode.get(); }
    public String getCourseName() { return courseName.get(); }
    public int getCreditHours() { return creditHours.get(); }
    public String getGrade() { return grade.get(); }
    public double getGpa() { return gpa.get(); }
    public String getStatus() { return status.get(); }
}
